/**
 * @file Revealed.java
 * @author Anshul Kumar-A4, Thomas Fisher-A5
 * @date 5 December 2015
 * @see KablewieTile.java
 * @brief A Revealed tile
 *
 * A KablewieTile that is revealed
 */ 

package kablewie;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.Timer;

/**
 * 
 * @class Revealed
 * @brief A Revealed tile
 *
 * A Revealed Tile, inherits from Tile
 */
public class Revealed extends KablewieTile {
	
	/**
	 * Constructor
	 * 
	 * @param isMine a boolean is mine or not
	 * @param isHidden a boolean is hidden or not
	 * @param isDefused a boolean is defused or not
	 */
	public Revealed(boolean isMine, boolean isHidden, boolean isDefused) {
		// Always set hidden to false as its the revealed tile.
		super(isMine, false, isDefused);
		URL url = getClass().getResource("/images/revealed.png");
		m_revealedImage = new ImageIcon(url);
	}
	
	/**
	 * Draw the number of mines near by the tile which is clicked
	 * 
	 * @param g a Graphics object used to render
	 * @param x the x position of the tile
	 * @param y the y position of the tile
	 */
	public void render(Graphics g, int x, int y) {

		g.drawImage(m_revealedImage.getImage(),
					x * KablewieTile.DEFAULT_TILE_WIDTH,
					y * KablewieTile.DEFAULT_TILE_HEIGHT,
					null);
		
		if (getNearbyMines() > 0) {
			/*
			 * using Spacing so that the number is drawn in the center
			 */
			
			g.setFont(new Font("Time new roman", Font.BOLD, FONT_SIZE));
			g.drawString(Integer.toString(getNearbyMines()),
				x * KablewieTile.DEFAULT_TILE_WIDTH + X_SPACING,
				y * KablewieTile.DEFAULT_TILE_HEIGHT + Y_SPACING);
		}
	}

	/**
	 * A recursive to reveal empty tiles
	 * 
	 * @param m_board a Board object that contains all the tiles
	 * @param i the row to get around
	 * @param j the column to get around
	 * @param gc the GameController for the current game
	 */
	public void revealPosition(KablewieTile[][] m_board, int i, int j,
			KablewieController gc) {
		
		if (i < 0 
			|| j < 0 
			|| i >= m_board.length 
			|| j >= m_board.length
			|| !(m_board[i][j].isHidden())) {
			// Escape if true
			return;
		}
		
		ArrayList<KablewieTile> tileArround = getTileArround(m_board, i, j);
		
		if (calculateNearbyMines(m_board[i][j], tileArround) == 0) {
			m_board[i][j] = new Revealed(false, false, false);
			Revealed r = (Revealed) m_board[i][j];
			
			r.calculateNearbyMines(r, getTileArround(m_board, i, j));
			
			revealPosition(m_board, i - 1, j - 1, gc);
			revealPosition(m_board, i - 1, j, gc);
			revealPosition(m_board, i - 1, j + 1, gc);
			revealPosition(m_board, i, j - 1, gc);
			revealPosition(m_board, i, j + 1, gc);
			revealPosition(m_board, i + 1, j - 1, gc);
			revealPosition(m_board, i + 1, j, gc);
			revealPosition(m_board, i + 1, j + 1, gc);
			
		} else {
			m_board[i][j] = new Revealed(false, false, false);
			Revealed r = (Revealed) m_board[i][j];
			r.calculateNearbyMines(r, getTileArround(m_board, i, j));
			
		}
		
		gc.repaintAll();
	}
	
	
	/**
	 * An animated reveal of tiles
	 * 
	 * @param board a Board object that contains all the tiles
	 * @param i the row to get around
	 * @param j the column to get around
	 * @param gc the GameController for the current game
	 */
	public void animatedReveal(KablewieTile[][] board,
			int i, int j, KablewieController gc) {
    	Timer timer = new Timer(REVEAL_RATE, new ActionListener(){
    		public void actionPerformed( ActionEvent e ){
    			if (	i < 0 
    					|| j < 0 
    					|| i >= board.length 
    					|| j >= board.length
    					|| !(board[i][j].isHidden())) {
    				// Escape if true
    				return;
    			}
    			
    			ArrayList<KablewieTile> tileArround = 
    					getTileArround(board, i, j);
    			
    			if (calculateNearbyMines(board[i][j], tileArround) == 0) {
    				
    				board[i][j] = new Revealed(false, false, false);
    				Revealed r = (Revealed) board[i][j];
    				
    				r.calculateNearbyMines(r, getTileArround(board, i, j));
    				
    				animatedReveal(board, i - 1, j - 1, gc);
    				animatedReveal(board, i - 1, j, gc);
    				animatedReveal(board, i - 1, j + 1, gc);
    				animatedReveal(board, i, j - 1, gc);
    				animatedReveal(board, i, j + 1, gc);
    				animatedReveal(board, i + 1, j - 1, gc);
    				animatedReveal(board, i + 1, j, gc);
    				animatedReveal(board, i + 1, j + 1, gc);
    				
    			} else {
    				board[i][j] = new Revealed(false, false, false);
    				Revealed r = (Revealed) board[i][j];
    				r.calculateNearbyMines(r, getTileArround(board, i, j));
    			}
    			
    			gc.repaintAll();
    		}
    	} );
    	timer.setRepeats( false );
    	timer.start();
	}

	private final ImageIcon m_revealedImage;
	private final int REVEAL_RATE = 20;
	private final int X_SPACING = 10;
	private final int Y_SPACING = 19;
	private final int FONT_SIZE = 15;
}
