/**
 * @file SecretTile.java
 * @author Thomas Williams-A4
 * @date 7 December 2015
 * @see KablewieTile.java
 * @brief A hidden Tile
 *
 * A KablewieTile that's contents are a secret to the user
 */ 

package kablewie;

import java.awt.Graphics;
import java.net.URL;

import javax.swing.ImageIcon;

public class SecretTile extends KablewieTile {
	
	/**
	 * SecretTile Constructor
	 * 
	 * @param isMine a boolean is mine or not
	 * @param isHidden a boolean is hidden or not
	 * @param isDefused a boolean is defused or not
	*/
	public SecretTile(boolean isMine, boolean isHidden,boolean isDefused) {
		// Always set hidden to false as its the hidden tile.
		super(isMine, true,false);
		URL url = getClass().getResource("/images/hidden.png");
		m_secretIcon=new ImageIcon(url);
	}
	
	/**
	 * Render the tile
	 *  
	 * @param g a Graphics object used to render
	 * @param x the X coordinate to render at
	 * @param y the Y coordinate to render at
	 */
	public void render(Graphics g, int x, int y) {
		g.drawImage(m_secretIcon.getImage(), 
					x * KablewieTile.DEFAULT_TILE_WIDTH,
					y * KablewieTile.DEFAULT_TILE_HEIGHT,
					null);
	}

	private ImageIcon m_secretIcon;
}
