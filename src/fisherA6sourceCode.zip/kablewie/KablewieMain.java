/**
 * @file KablewieMain.java
 * @author Thomas Phelps-A4, Victoria Charvis-A5
 * @date 4 December 2015
 * @see KablewieSettings.java
 * @brief Starts the game
 *
 * Starts the game then creates and
 * calls the other components.
 */

package kablewie;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

import gamesuite.Player;

public class KablewieMain {

	/**
	 * Method for creating a JFrame for the mainMenu
	 * 
	 * @see KablewieSettings.java
	 */
	public KablewieMain() {
		// Create the frame.
		m_frame = new JFrame("Kablewie");
		m_frame.setIconImage(new ImageIcon("images/Kablewie.png").getImage());
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		// Set frame boundaries.
		m_frame.setSize(FRAME_WIDTH, FRAME_HEIGHT);
		m_frame.setLocation(dim.width / 2 - m_frame.getSize().width / 2,
				dim.height / 2 - m_frame.getSize().height / 2);

		// Set window to close when exited.
		m_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Show the frame.
		m_frame.setVisible(true);
		new KablewieSettings(m_frame, this);
	}
	
	/**
	 * Initialisation method.
	 * 
	 * @param args a String Array of arguments passed from the command line.
	 */
	public static void main(String[] args) {
		// Create a Kablewie instance to escape static scope.
		new KablewieMain();
	}

	/**
	 * Simple method for passing board and player information to the game
	 * controller
	 * 
	 * @param board
	 * @param player
	 * 
	 * @see LudoController.java
	 * @return if the game started successfully
	 */
	public boolean startGame(KablewieBoard board, Player player,
			KablewieSettings menu) {
		try {
			m_frame.getContentPane().removeAll();
			new KablewieController(board, player, m_frame, menu);
			return true;
		} catch (Exception e) {
			System.err.println(e);
			return false;
		}
	}
	
	/**
	 * 
	 * @param board the loaded board
	 * @param player the loaded player
	 * @param time the loaded time
	 * @return if the loaded game started successfully
	 */
	public boolean startLoadedGame(KablewieBoard board,
			Player player, String time){
		try {
			m_frame.getContentPane().removeAll();
			m_frame.setLayout(null);
			new KablewieController(board, player, time, m_frame);
			return true;
		} catch (Exception e) {
			System.out.println(e);
			return false;
		}
		
	}
	
	private JFrame m_frame;
	
	private final int FRAME_WIDTH = 640, FRAME_HEIGHT = 480;
}
