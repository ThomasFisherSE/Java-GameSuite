/**
 * @file Mine.java
 * @author Josh Townsend-A4
 * @date 7 December 2015
 * @see KablewieTile.java
 * @brief A Mine tile
 *
 * A Mine tile, a KablewieTile where a mine resides
 */

package kablewie;

import java.awt.Graphics;
import java.net.URL;

import javax.swing.ImageIcon;

import gamesuite.Tile;

public class Mine extends KablewieTile {
	
	/**
	 * Mine Constructor
	 * 
	 * @param isMine a boolean is mine or not
	 * @param isHidden a boolean is hidden or not
	 * @param isDefused a boolean is defused or not
	*/
	public Mine(boolean isMine, 
				boolean isHidden, 
				boolean isDefused,
				String path) {
		
		/**
		 *  Always set hidden to false as Mine is a visible tile.
		 *  Always set mine to true as Mine is a mine.
		 */ 
		super(true, true, false);
		URL url = getClass().getResource(path);
		m_mineImage = new ImageIcon(url);
	}
	
	/**
	 *  render the tile
	 *  
	 * @param g a Graphics object used to render
	 * @param x the X coordinate to render at
	 * @param y the Y coordinate to render at
	 */
	public void render(Graphics g, int x, int y) {
		g.drawImage(m_mineImage.getImage(), 
					x * Tile.DEFAULT_TILE_WIDTH,
					y * Tile.DEFAULT_TILE_HEIGHT,
					null);
	}

	private ImageIcon m_mineImage;

}
