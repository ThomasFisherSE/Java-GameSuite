/**
 * @file KablewieBoard.java
 * @author Ethan Davies-A4 Victoria Charvis, Ibrahim Shehu, Thomas Fisher,
   	Eromosele Gideon-A5
 * @date 7 December 2015
 * @see KablewieTile.java, Board.java
 * 
 * @brief Contain the Information of the current Board
 * and various helper methods for manipulating
 * the board.
 */ 

package kablewie;

import java.awt.*;
import java.util.*;
import javax.swing.JOptionPane;

import gamesuite.*;

public class KablewieBoard extends Board {
	/**
	 * Constructor for a KablewieBoard
	 * 
	 * @param boardSize the size of the board
	 * @param numMines an int for number of mines
	 */
	public KablewieBoard(int boardSize, int numMines) {
		super(boardSize, boardSize);
		
		this.m_size = boardSize;
	
		// Set Class variables
		this.m_mineCount = numMines;
		
		// Create a revealed tile for the sake of method calls.
		m_reveal = new Revealed(false, false, false);
		
		// Setup the board.
		setBoardDimensions();
		placeMines();
	}
	
	/**
	 * Get a kablewie tile at location (x,y)
	 * 
	 * @param x the x coordinate of the tile
	 * @param y the y coordinate of the tile
	 * @return the KablewieTile at coordinates (x,y)
	 */
	public KablewieTile getTile(int x, int y) {
		return ((KablewieTile) super.getTile(x,y));
	}
	
	/**
	 * Get the 2D array of KablewieTile objects
	 * 
	 * @return the 2D array of KablewieTile objects
	 */
	public KablewieTile[][] getTiles() {
		return ((KablewieTile[][]) super.getTiles());
	}
 	
 	/**
 	 * Get the number of defused tiles
 	 * 
	 * @return an int with the number of defused tiles
	 */
	public int getNumberDefused() {
		int numberDefused = 0;
		
		for (int i = 0; i < m_size; ++i) {
			for (int j = 0; j < m_size; ++j) {
				try {
					if (getTile(i,j).isDefused() &&
							getTile(i,j).isMine()) {
						++numberDefused;
					}
				} catch (IndexOutOfBoundsException e) {
					System.err.println("Board.java :: getDefusedTile() --> "
							+ "Index Out of Bounds \n"
							+ "i:" + i + " j:" + j + " size: " + 
							m_size);
				}
			}
		}
		
		return numberDefused;
	}
 	
	/**
	 * Returns if game is lost
	 * 
	 * @return the value of m_gameLost which is true if the game is lost
	 */
	public boolean getGameLost() {
		return m_gameLost;
	}

	/**
	 * Returns if the game is won
	 * 
	 * @return the value of m_gameWon which is true if the game is won
	 */
	public boolean getGameWon() {
		return m_gameWon;
	}
	
	/**
	 * Get the number of hidden tiles
	 * 
	 * @return an int with the number of hidden tiles
	 */
	public int getHiddenTile() {
		int hiddenTile = 0;
		
		for (int i = 0; i < m_size; ++i) {
			for (int j = 0; j < m_size; ++j) {
				try {
					if (getTile(i,j).isHidden()) {
						++hiddenTile;
					}
				} catch (IndexOutOfBoundsException e) {
					System.err.println("Board.java :: getHiddenTile() --> "
							+ "Index Out of Bounds \n"
							+ "i:" + i + " j:" + j + " size: " +
							m_size);
				}
			}
		}
		
		return hiddenTile;
	}

	/**
	 * Gets the mine count
	 * 
	 * @return the mine count
	 */
	public int getMineCount() {
		return m_mineCount;
	}
	
	/**
	 * Get the number of revealed tiles
	 * 
	 * @return an int with the number of revealed tiles
	 */
	public int getRevealedTile() {
		int revealedTile = 0;
		
		for (int i = 0; i < m_size; ++i) {
			for (int j = 0; j < m_size; ++j) {
				try {
					if (!(getTile(i,j).isHidden())) {
						++revealedTile;
					}
				} catch (IndexOutOfBoundsException e) {
					System.err.println("Board.java :: getHiddenTile() --> "
							+ "Index Out of Bounds \n"
							+ "i:" + i + " j:" + j + " size: " + 
							m_size);
				}
			}
		}
		
		return revealedTile;
	}
	

	/**
	 * Gets the time passed
	 * 
	 * @return value of the time passed
	 */
	public String getTimePassed() {
		return m_timePassed;
	}
	
	/**
	 * Sets the dimensions of the board
	 */
	private void setBoardDimensions() {
		// Create board
		setTileArray(new KablewieTile[m_size][m_size]);
		
		// Sets the dimensions HxW of the board that is to be created
		for (int x = 0; x < m_size; x++) {
			for (int y = 0; y < m_size; y++) {
				setTile(x,y,new SecretTile(false,true,false));
			}
		}
	}

	/**
	 * Sets the states of the loaded tiles
	 * 
	 * @param column the column the tile is in
	 * @param row the row the tile is in
	 * @param state the state the tile is in(Diffused,Hidden,Mine)
	 */
	public void setState(int column, int row, String state, 
			boolean isProperty) {
		if (state.equalsIgnoreCase("D")) {
			if (isProperty){
				getTile(column, row).setDefused(true);
			} else {
				getTile(column, row).setDefused(false);
			}
		} else if (state.equalsIgnoreCase("M")) {
			if (isProperty){
				getTile(column, row).setMine(true);
			} else {
				getTile(column, row).setMine(false);
			}
		} else if (state.equalsIgnoreCase("H")) {
			if (isProperty){
				getTile(column, row).setHidden(true);
			} else {
				getTile(column, row).setHidden(false);
			}
		}
	}

	/**
	 * This method is used to defuse tiles on the board
	 * after a users turn, storing whether the tile was
	 * a mine or not.
	 * 
	 * @param x an int which is the X position of the click
	 * @param y an int which is the Y position of the click
	 */
	public void defuseTile(int x, int y) {		
		if (inLimit(x, y)) {
			
			boolean isMine = getTile(x,y).isMine();
			boolean isDefused = getTile(x,y).isDefused();
			boolean isHidden = getTile(x,y).isHidden();
			
			if (isHidden) {
				if (!(isDefused)) {
					setTile(x,y, new Defused(isMine, true, true));
					haveWon();
				} else {
					setTile(x,y, new SecretTile(isMine, true, false));
				} 
			}  else {
				JOptionPane.showMessageDialog(null, 
						"You can't diffuse a revealed tile", "Invalid Move",
						JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}
	
	/**
	 * checks if the game have been won or not
	 */
	public void haveWon() {
		if (getRevealedTile() + getNumberDefused() == m_size *
				m_size) {
			m_gameLost = false;
			m_gameWon = true;
		}
	}
	
	/**
	 * Hides all bomb tiles on the board
	 */
	 public void hideBombTile() {
		 for (int x=0; x < m_size; x++ ){
			 for (int y=0; y < m_size; y++){
				 if (getTile(x,y).isMine()) {  
					 setTile(x,y, new SecretTile(true, true, false));
	              }
	         }		
	     }
	 }
	 
	/**
	 * it check if x,y are in the range of the board or not
	 * 
	 * @param x an int for the row
	 * @param y an int for the column
	 * 
	 * @return true if x, y are in range
	 */
	public boolean inLimit(int x, int y) {
		return !(x >= m_size
				|| y >= m_size
				|| x < 0
				|| y < 0);
	}
	
	/**
	 * Loads the graphics
	 * 
	 * @param gc, the GameController for the current game
	 */
	public void loadGraphics(KablewieController gc) {
		//for every tile in the game set the graphics
		for (int i=0;i<m_size;i++) {
			for (int j=0;j<m_size;j++) {
				
				boolean isMine = getTile(i,j).isMine();
				boolean isDefused = getTile(i,j).isDefused();
				boolean isHidden = getTile(i,j).isHidden();
				
				//Setting correct images
				if (getTile(i,j).isDefused()) {
					setTile(i,j,new Defused(isMine, isHidden, 
							isDefused));
				} else if (getTile(i,j).isHidden()==false) {
					if (!(isDefused)) {
						setTile(i,j,new Revealed(isMine, isHidden, 
								isDefused));
						
						getTile(i,j).setHidden(true);
						m_reveal.revealPosition(getTiles(), i, j, gc);
						haveWon();
					}
				}
			}
		}
	}
	
	
	/**
	 * Renders the games UI
	 * 
	 * @param g a Graphics object for rendering the UI
	 * @param player a Player object with the info to be displayed
	 * @param timePassed a String with the time that has passed.
	 */
	public void renderInfo(Graphics g, Player player, String timePassed) {
		Font timeNewRoman = new Font("Time new roman", Font.BOLD, FONT_SIZE);
		
		// Positioning Values.
		int x = START_X;
		int y = START_Y;
		
		g.setFont(timeNewRoman);
		g.setColor(Color.RED);
		g.drawString("Name : " + player.getUsername(), x, y);
		
		x = x + X_SPACING;
		
		if (timePassed == null) {
			g.drawString("Time: 00:00:00", x, y);
		} else {
			g.drawString("Time: " + timePassed, x, y);
			m_timePassed = timePassed;
		}
		
		x = START_X;
		y = y + Y_SPACING;
		g.setColor(Color.BLUE);
		g.drawString("Defused Mine : " + getNumberDefused(), x, y);
		
		x = x + X_SPACING;
		g.drawString("Mines Present : " + m_mineCount, x, y);
		
		y = y + Y_SPACING;
		x = START_X;
		g.drawString("Hidden Square : " + getHiddenTile(), x, y);
		
		x = x + X_SPACING;
		g.drawString("Revealed Square : " + getRevealedTile(), x, y);
	}
	
	/**
	 * Resets the game so that it can be played again
	 */
	public void reset() {
		setBoardDimensions();
		placeMines();
		m_gameLost = false;
		m_gameWon = false;
	}
	
	/**
	 * This method is used to reveal tiles on the board
	 * after a users turn, and then takes action based
	 * on what tile is revealed.
	 * 
	 * @param x an int which is the X position of the click
	 * @param y an int which is the Y position of the click
	 * @param gc the GameController for the current game
	 */
	public void revealTile(int x, int y, KablewieController gc) {
		
		
		if (inLimit(x, y) && !(getTile(x,y).isDefused())) {
			
			if (getTile(x,y).isHidden() && 
					!(getTile(x,y).isMine())) {
				
				m_reveal.revealPosition(getTiles(), x, y, gc);
				
				/*
				if (gc.isTesting()) {
					m_reveal.revealPosition(m_board, y, x, gc);
				} else {
					m_reveal.animatedReveal(m_board, y, x, gc);
				}
				*/
				
				haveWon();
				
			} else if (getTile(x,y).isMine()) {
				this.m_gameWon = false;
				this.m_gameLost = true;
				setTile(x,y, new Mine(true, true, false, 
						"/images/mineX.jpg"));
				for (int i = 0; i < m_size; ++i) {
					for (int j = 0; j < m_size; ++j) {
						if (getTile(i,j).isMine() && !(i == x && j == y)) {
							setTile(i,j, new Mine(true, true, false, 
									"/images/mine.png"));
						}
					}
				}	
			} else if (!getTile(x,y).isHidden()) {
				JOptionPane.showMessageDialog(null, 
						"You can't reveal a revealed tile", "Invalid Move",
						JOptionPane.INFORMATION_MESSAGE);
			}
		} else {
			JOptionPane.showMessageDialog(null, 
					"You can't reveal a diffused tile", "Invalid Move",
					JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	/**
	 * Shows all bomb tiles on the board
	 */
	public void showBombTile() {
		
		for (int x=0; x < m_size - 1; x++ ){
	            for (int y=0; y < m_size - 1; y++){
			
	                if (getTile(x,y).isMine()) {

	                	setTile(x,y,new Mine(true,true,false,"/images/mine.png"));
	                	
	                    for (int i = 0; i < m_size; ++i) {
	                        for (int j = 0; j < m_size; ++j) {
	                            if (getTile(i,j).isMine() && 
	                            		!(i == x && j == y)) {
	                            	setTile(i,j, new Mine(true, true,
	                                		false, "/images/mine.png"));
	                            }
	                        }
	                    }	
	                }
	            }		
		}
	 }

	/**
	 * Place the mines onto the board.
	 */
	private void placeMines() {
		// This places the mines in random areas on the board(In the array)
		Random rnd = new Random();
		int mineCount = this.m_mineCount;
		while (mineCount > 0) {
			int row = rnd.nextInt(m_size);
			int column = rnd.nextInt(m_size);

			if (getTile(column, row).isMine()) {

			} else {
				getTile(column, row).setTileType(true, true);
				mineCount--;
			}
		}
	}
	
	private int m_size;
	private int m_mineCount;
	private boolean m_gameWon = false;
	private boolean m_gameLost = false;
	private Revealed m_reveal;
	private String m_timePassed;
	
	public static final int DEFAULT_SIZE = 10;
	public static final int DEFAULT_MINES = DEFAULT_SIZE;
	public static final int MAX_SIZE = 30;
	public static final int MAX_MINES = MAX_SIZE - 1;
	public static final int MIN_SIZE = 2;
	public static final int MIN_MINES = 1;
	
	private final int FONT_SIZE = 12;
	private final int START_X = 1;
	private final int START_Y = 10;
	private final int X_SPACING = 180;
	private final int Y_SPACING = 19;
}
