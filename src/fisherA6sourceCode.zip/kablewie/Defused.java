/**
 * @file Defused.java
 * @author Josh Townsend-A4
 * @date 7 December 2015
 * @see KablewieTile.java
 * @brief A Defused Tile
 *
 * A defused tile, where a player thinks a bomb may be
 */

package kablewie;

import java.awt.Graphics;
import java.net.URL;

import javax.swing.ImageIcon;

import gamesuite.*;

public class Defused extends KablewieTile {

	/**
	 * Constructor
	 * 
	 * @param isMine a boolean is mine or not
	 * @param isHidden a boolean is hidden or not
	 * @param isDefused a boolean is defused or not
	 */
	public Defused(boolean isMine, boolean isHidden, boolean isDefused) {
		super(isMine, isHidden, isDefused);
		URL url = getClass().getResource("/images/defused.png");
		m_defusedIcon = new ImageIcon(url);
	}

	/**
	 * Render the tile
	 *  
	 * @param g a Graphics object used to render
	 * @param x the X coordinate to render at
	 * @param y the Y coordinate to render at
	 */
	public void render(Graphics g, int x, int y) {
		g.drawImage(m_defusedIcon.getImage(),
					x * Tile.DEFAULT_TILE_WIDTH,
					y * Tile.DEFAULT_TILE_HEIGHT,
					null);
	}
	
	private ImageIcon m_defusedIcon;
	
}
