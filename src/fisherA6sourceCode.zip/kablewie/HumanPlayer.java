/**
 * @file HumanPlayer.java
 * @author Zongbo Xu-A4
 * @date 5 December 2015
 * @see Player.java, LudoPlayer.java
 * @brief A class for Human players.
 *
 * A human player that's playing Kablewie
 */ 

package kablewie;

import gamesuite.Player;

public class HumanPlayer extends Player  {
	
	/**
	 * Constructor
	 * 
	 * @param name the players name
	 */
	public HumanPlayer(String name) {
		super(name);
	}
	
	/**
	 * Gets if it's the human players turn
	 * 
	 * @return boolean if it's the human players turn
	 */
	public boolean getPlayersTurn() {
		return m_playersTurn;
	}
	
	/**
	 * Sets if it's the human player turn
	 */
	public void takeTurn() {
		m_playersTurn = true;
	}

	private boolean m_playersTurn = true;

}
