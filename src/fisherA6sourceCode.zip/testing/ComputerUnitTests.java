/**
 * @file ComputerUnitTests.java

 * @author Thomas Fisher
 * @Date 13/03/2016
 * @see KablewieAi.java
 * @brief Tests computer player
 * 
 * Tests methods in Computer, and whether the computer AI works correctly
 */

package testing;

import static org.junit.Assert.*;

import org.junit.Test;

import kablewie.*;

/**
 * 
 * @class ComputerUnitTests
 * @brief Tests computer player
 * 
 * Tests methods in Computer, and whether the computer AI works correctly
 */
public class ComputerUnitTests {
	
	/**
	 * Testing the low intelligence preset in the JMenu
	 */
	@Test
	public void testLowIntelligencePreset() {
		KablewieAi tester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.LOW_PROBABILITY);
		
		assertEquals("Test if the correct intelligence is set by clicking"
				+ " the Low-Intelligence preset",
				KablewieAi.LOW_PROBABILITY, tester.getIntelligence());
	}
	
	/**
	 * Testing the normal intelligence preset in the JMenu
	 */
	@Test
	public void testNormalIntelligencePreset() {
		KablewieAi tester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.NORMAL_PROBABILITY);
		
		assertEquals("Test if the correct intelligence is set by clicking"
				+ " the Normal-Intelligence preset",
				KablewieAi.NORMAL_PROBABILITY, tester.getIntelligence());
	}
	
	/**
	 * Testing the high intelligence preset in the JMenu
	 */
	@Test
	public void testHighIntelligencePreset() {
		KablewieAi tester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.PERFECT_PROBABILITY);
		
		assertEquals("Test if the correct intelligence is set by clicking"
				+ " the High-Intelligence preset",
				KablewieAi.PERFECT_PROBABILITY, tester.getIntelligence());
	}
	
	/**
	 * Testing the cannot lose intelligence preset in the JMenu
	 */
	@Test
	public void testCantLosePreset() {
		KablewieAi tester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.CANNOT_LOSE);
		
		assertEquals("Test if the correct intelligence is set by using"
				+ " the cannot lose preset",
				KablewieAi.CANNOT_LOSE, tester.getIntelligence());
	}
	
	/**
	 * Testing the computer player playing on a large board
	 */
	@Test
	public void testAiOnLargeBoard() {
		KablewieAi tester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.PERFECT_PROBABILITY);
		
		Thread testThread = new Thread(tester);
		testThread.start();
		tester.setTime(KablewieAi.TEST_SLEEP_TIME);
		tester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: testAiOnLargeBoard() -->"
					+ " Error interrupting thread.");
		}
		
		assertEquals("The computer player should be able to play to completion"
				+ " on a large board", true, tester.checkGameOver());
	}
	
	/**
	 * Testing the computer player playing on a default board
	 */
	@Test
	public void testAiOnDefaultBoard() {
		KablewieAi tester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.PERFECT_PROBABILITY);
		
		Thread testThread = new Thread(tester);
		testThread.start();
		tester.setTime(KablewieAi.TEST_SLEEP_TIME);
		tester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: testAiOnDefaultBoard()"
					+ " --> Error interrupting thread.");
		}
		
		assertEquals("The computer player should be able to play to completion"
				+ " on a default board", true, tester.checkGameOver());
	}
	
	/**
	 * Testing the computer player playing on a small board
	 */
	@Test
	public void testAiOnSmallBoard() {
		KablewieAi tester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.PERFECT_PROBABILITY);
		
		Thread testThread = new Thread(tester);
		testThread.start();
		tester.setTime(KablewieAi.TEST_SLEEP_TIME);
		tester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: testAiOnSmallBoard() -->"
					+ " Error interrupting thread.");
		}
		
		assertEquals("The computer player should be able to play to completion"
				+ " on a small board", true, tester.checkGameOver());
	}
	
	/**
	 * Testing the computer player playing with the max number of mines
	 */
	@Test
	public void testAiWithMaxMines() {
		KablewieAi tester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.PERFECT_PROBABILITY);
		
		Thread testThread = new Thread(tester);
		testThread.start();
		tester.setTime(KablewieAi.TEST_SLEEP_TIME);
		tester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: testAiWithMaxMines() -->"
					+ " Error interrupting thread.");
		}
		
		assertEquals("The computer player should be able to play to completion"
				+ " with the max number of mines", 
				true, tester.checkGameOver());
	}
	
	/**
	 * Testing the computer player playing with the default number of mines
	 */
	@Test
	public void testAiWithDefaultMines() {
		KablewieAi tester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.PERFECT_PROBABILITY);
		
		Thread testThread = new Thread(tester);
		testThread.start();
		tester.setTime(KablewieAi.TEST_SLEEP_TIME);
		tester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: testAiWithDefaultMines()"
					+ " --> Error interrupting thread.");
		}
		
		assertEquals("The computer player should be able to play to completion"
				+ " with the default number of mines", 
				true, tester.checkGameOver());
	}
	
	/**
	 * Testing the computer player playing with the min number of mines
	 */
	@Test
	public void testAiWithMinMines() {
		KablewieAi tester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.PERFECT_PROBABILITY);
		
		Thread testThread = new Thread(tester);
		testThread.start();
		tester.setTime(KablewieAi.TEST_SLEEP_TIME);
		tester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: testAiWithMinMines() -->"
					+ " Error interrupting thread.");
		}
		
		assertEquals("The computer player should be able to play to completion"
				+ " with the min number of mines", 
				true, tester.checkGameOver());
	}
	
	/**
	 * Testing the computer player playing with the min possible intelligence
	 */
	@Test
	public void testMinIntelligence() {
		KablewieAi tester = new KablewieAi(
				m_interactingClass.createGameController(), 
				KablewieAi.MINIMUM_INTELLIGENCE);
		
		Thread testThread = new Thread(tester);
		testThread.start();
		tester.setTime(KablewieAi.TEST_SLEEP_TIME);
		tester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: testMinIntelligence() -->"
					+ " Error interrupting thread.");
		}
		
		assertEquals("The computer player should be able to play to completion"
				+ " with min intelligence", true, tester.checkGameOver());
	}
	
	/**
	 * Testing the computer player playing with the max possible intelligence
	 */
	@Test
	public void testMaxIntelligence() {
		KablewieAi tester = new KablewieAi(
				m_interactingClass.createGameController(), 
				KablewieAi.MAXIMUM_INTELLIGENCE);
		
		Thread testThread = new Thread(tester);
		testThread.start();
		tester.setTime(KablewieAi.TEST_SLEEP_TIME);
		tester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: testMaxIntelligence() -->"
					+ " Error interrupting thread.");
		}
		
		assertEquals("The computer player should be able to play to completion"
				+ " with max intelligence", true, tester.checkGameOver());
	}
	
	/**
	 * Testing the computer player playing when mines are revealed
	 */
	@Test
	public void testAiWhenMinesRevealed() {
		KablewieBoard testBoard = new KablewieBoard(
				KablewieBoard.DEFAULT_SIZE, KablewieBoard.DEFAULT_MINES);
		
		KablewieAi tester = new KablewieAi(
				m_interactingClass.createGameController(), 
				KablewieAi.PERFECT_PROBABILITY);
		
		testBoard.showBombTile();
		
		Thread testThread = new Thread(tester);
		testThread.start();
		tester.setTime(KablewieAi.TEST_SLEEP_TIME);
		tester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: testAiWhenMinesRevealed()"
					+ " --> Error interrupting thread.");
		}
		
		assertEquals("The computer player should be able to play to completion"
				+ " when mines are revealed", true, tester.checkGameOver());
	}
	
	/**
	 * Testing running multiple computer players after each other
	 */
	@Test
	public void testRunningAiConsecutively() {
		new KablewieBoard(
				KablewieBoard.DEFAULT_SIZE, KablewieBoard.DEFAULT_MINES);
		
		KablewieController testGameController = 
				m_interactingClass.createGameController();
		
		KablewieAi tester = new KablewieAi(testGameController, 
				KablewieAi.MAXIMUM_INTELLIGENCE);
		
		Thread testThread = new Thread(tester);
		testThread.start();
		tester.setTime(KablewieAi.TEST_SLEEP_TIME);
		tester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: "
					+ "testRunningAiConsecutively() -->"
					+ " Error interrupting thread.");
		}
		
		tester = new KablewieAi(testGameController, 
				KablewieAi.MAXIMUM_INTELLIGENCE);
		
		testThread = new Thread(tester);
		testThread.start();
		tester.setTime(KablewieAi.TEST_SLEEP_TIME);
		tester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: "
					+ "testRunningAiConsecutively() -->"
					+ " Error interrupting thread.");
		}
		
		assertEquals("The computer player should be able to play to completion"
				+ " when running several computer players consecutively", 
				true, tester.checkGameOver());
	}
	
	/**
	 * Testing the generateMoveLists() method
	 */
	@Test
	public void testGeneratingMoves() {
		KablewieAi newBoardTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.PERFECT_PROBABILITY);
		
		KablewieAi midGameTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.CANNOT_LOSE);
		
		
		/**
		 * Make 9 perfect moves; since there are 10 mines, 
		 * after 9 perfect moves, there should always be a smart move possible
		 */
		for (int i = 0; i<10; i++) {
			midGameTester.makePerfectMove();
		}
		
		assertEquals("Move lists should be able to be generated for a new "
				+ "board", 
				false, newBoardTester.generateMoves());
		
		assertEquals("Move lists should be able to be generated mid-game", 
				true, midGameTester.generateMoves());
	}
	
	/**
	 * Testing the makeStupidMove() method
	 */
	@Test
	public void testMakeStupidMove() {
		KablewieAi newBoardTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.PERFECT_PROBABILITY);
		
		KablewieAi midGameTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.CANNOT_LOSE);
		
		for (int i = 0; i<10; i++) {
			midGameTester.makePerfectMove();
		}
		
		KablewieAi gameOverTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.CANNOT_LOSE);
		
		Thread testThread = new Thread(gameOverTester);
		testThread.start();
		gameOverTester.setTime(KablewieAi.TEST_SLEEP_TIME);
		gameOverTester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: "
					+ "testMakeStupidMove() -->"
					+ " Error interrupting thread.");
		}
		
		assertEquals("A stupid move should be able to be made on a new board", 
				true, newBoardTester.makeStupidMove());
		
		assertEquals("A stupid move should be able to be made mid-game", 
				true, midGameTester.makeStupidMove());
		
		assertEquals("A stupid move should be able to be made when "
				+ "the game is over", false, gameOverTester.makeStupidMove());
	}
	
	/**
	 * Testing the makePerfectMove() method
	 */
	@Test
	public void testMakePerfectMove() {
		KablewieAi newBoardTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.PERFECT_PROBABILITY);
		
		KablewieAi midGameTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.CANNOT_LOSE);
		
		for (int i = 0; i<10; i++) {
			midGameTester.makePerfectMove();
		}
		
		KablewieAi gameOverTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.CANNOT_LOSE);
		
		Thread testThread = new Thread(gameOverTester);
		testThread.start();
		gameOverTester.setTime(KablewieAi.TEST_SLEEP_TIME);
		gameOverTester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: "
					+ "testMakePerfectMove() -->"
					+ " Error interrupting thread.");
		}
		
		assertEquals("A perfect move should be able to "
				+ "be made on a new board", 
				true, newBoardTester.makePerfectMove());
		
		assertEquals("A perfect move should be able to "
				+ "be made mid-game", 
				true, midGameTester.makePerfectMove());
		
		assertEquals("A perfect move should be able to be made when "
				+ "the game is over", false,
				gameOverTester.makePerfectMove());
	}
	
	/**
	 * Testing the makeMove() method
	 */
	@Test
	public void testMakeMove() {
		KablewieAi newBoardTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.PERFECT_PROBABILITY);
		
		KablewieAi midGameTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.CANNOT_LOSE);
		
		for (int i = 0; i<10; i++) {
			midGameTester.makePerfectMove();
		}
		
		KablewieAi gameOverTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.CANNOT_LOSE);
		
		Thread testThread = new Thread(gameOverTester);
		testThread.start();
		gameOverTester.setTime(KablewieAi.TEST_SLEEP_TIME);
		gameOverTester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: "
					+ "testMakeMove() -->"
					+ " Error interrupting thread.");
		}
		
		assertEquals("A move should be able to be made on a new board", 
				true, newBoardTester.makeMove());
		
		assertEquals("A move should be able to be made mid-game", 
				true, midGameTester.makeMove());
		
		assertEquals("A move should be able to be made when the game is over",
				false, gameOverTester.makeMove());
	}
	
	/**
	 * Testing the makeSmartMove() method
	 */
	@Test
	public void testMakeSmartMove() {
		KablewieAi newBoardTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.PERFECT_PROBABILITY);
		
		KablewieAi midGameTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.CANNOT_LOSE);
		
		for (int i = 0; i<10; i++) {
			midGameTester.makePerfectMove();
		}
		
		KablewieAi gameOverTester = new KablewieAi(
				m_interactingClass.createGameController(),
				KablewieAi.CANNOT_LOSE);
		
		Thread testThread = new Thread(gameOverTester);
		testThread.start();
		gameOverTester.setTime(KablewieAi.TEST_SLEEP_TIME);
		gameOverTester.toggleAi();
		
		try {
			testThread.join();
		} catch (InterruptedException e) {
			System.err.println("ComputerUnitTests :: "
					+ "testMakeSmartMove() -->"
					+ " Error interrupting thread.");
		}
		
		assertEquals("A smart move should be able to "
				+ "be made on a new board", 
				true, newBoardTester.makeSmartMove());
		
		assertEquals("A smart move should be able to be made mid-game", 
				true, midGameTester.makeSmartMove());
		
		assertEquals("A smart move should not be made when the game is over",
				false, gameOverTester.makeSmartMove());
	}
	
	IntegrationTests m_interactingClass = new IntegrationTests();
}
