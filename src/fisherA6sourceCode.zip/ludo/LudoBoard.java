/**
 * @file LudoBoard.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see Board.java
 * @brief A Ludo Board
 *
 * A Ludo Board made up of LudoTile objects. 
 */

package ludo;

import gamesuite.Board;

public class LudoBoard extends Board {

	/**
	 * Constructor for a LudoBoard
	 *
	 * @param controller the LudoController in charge of the game
	 */
	public LudoBoard(LudoController controller) {
		super(BOARD_SIZE, BOARD_SIZE);
		m_controller = controller;
		setTileArray(new LudoTile[BOARD_SIZE][BOARD_SIZE]);
		
		if (initialiseBoard()) {
			System.out.println("Board initialised without errors.");
		}
		
		if (generateBoard()) {
			System.out.println("Board generated without errors.");
		}
	}
	
	/**
	 * Get the home area of a certain player
	 *
	 * @param color the color of the player whose home area to get
	 * @return the home area of the player
	 */
	public HomeArea getHomeArea(String color) {
		if (color.equals("red")) {
			return m_redHome;
		} else if (color.equals("blue")) {
			return m_blueHome;
		} else if (color.equals("yellow")) {
			return m_yellowHome;
		} else if (color.equals("green")) {
			return m_greenHome;
		} else {
			System.err.println("Invalid color, couldn't retrieve home area.");
			return null;
		}
	}
	
	/**
	 * Get the starting area of a particular player
	 *
	 * @param color the color of the player whose starting area to get
	 * @return the starting area of the player
	 */
	public StartingArea getStartingArea(String color) {
		if (color.equals("red")) {
			return m_redStart;
		} else if (color.equals("blue")) {
			return m_blueStart;
		} else if (color.equals("yellow")) {
			return m_yellowStart;
		} else if (color.equals("green")) {
			return m_greenStart;
		} else {
			System.err.println("Invalid color, "
					+ "couldn't retrieve starting area.");
			return null;
		}
	}
	
	/**
	 * Get a LudoTile at certain coordinates
	 *
	 * @param x the x coordinate of the tile
	 * @param y the y coordinate of the tile
	 * @return the tile at coordinates (x,y)
	 */
	public LudoTile getTile(int x, int y) {
		return (LudoTile) super.getTile(x, y);
	}
	
	/**
	 * Initialise the board
	 *
	 * @return true if successful, false otherwise
	 */
	private boolean initialiseBoard() {
		try {
			for (int i = 0; i < BOARD_SIZE; i++) {
				for (int j = 0; j < BOARD_SIZE; j++) {
					setTile(i,j, null);
				}
			}
		} catch (Exception e) {
			System.err.println("Error initialising board: " + e);
			return false;
		}
		
		return true;
	}
	
	/**
	 * Generate the board
	 *
	 * @return true if successful, false otherwise
	 */
	private boolean generateBoard() {
		return generateStartingAreas() && 
				generateHomeAreas() &&
				generateMainTiles();
	}
	
	/**
	 * Generate the main tiles of the board
	 *
	 * @return true if successful, false otherwise
	 */
	private boolean generateMainTiles() {
		return generateStartingTiles() &&
				generateHomeColumns() &&
				generateNormalTiles();
	}
	
	/**
	 * Generate the normal, blank tiles on the board
	 *
	 * @return true if successful, false otherwise
	 */
	private boolean generateNormalTiles() {
		try {
			for (int i = 0; i < BOARD_SIZE; i++) {
				for (int j = 0; j < BOARD_SIZE; j++) {
					if (getTile(i,j) == null) {
						setTile(i,j, new NormalTile(i, j));
					}
				}
			}
		} catch (Exception e) {
			System.err.println("Error occured when generating normal tiles: "
		+ e);
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	
	/**
	 * Generate the home columns
	 *
	 * @return true if successful, false otherwise
	 */
	private boolean generateHomeColumns() {
		try {
			for (int i = HOME_COLUMN_START_RG; i < HOME_COLUMN_END_RG; i++) {
				setTile(i, HOME_COLUMN, new HomeColumnTile(i, HOME_COLUMN,
						m_controller.getGreenPlayer()));
				setTile(HOME_COLUMN, i, new HomeColumnTile(HOME_COLUMN, i,
						m_controller.getRedPlayer()));
			}
			
			for (int i = HOME_COLUMN_START_BY; i < HOME_COLUMN_END_BY; i++) {
				setTile(i, HOME_COLUMN, new HomeColumnTile(i, HOME_COLUMN,
						m_controller.getBluePlayer()));
				setTile(HOME_COLUMN,i, new HomeColumnTile(HOME_COLUMN, i,
						m_controller.getYellowPlayer()));
			}
		} catch (Exception e) {
			System.err.println(e);
			return false;
		}
		
		return true;
		
	}
	
	/**
	 * Generate the starting tiles
	 *
	 * @return true if successful, false otherwise
	 */
	private boolean generateStartingTiles() {
		try {
			setTile(StartingTile.RED_X, StartingTile.RED_Y, new StartingTile(
					StartingTile.RED_X, StartingTile.RED_Y,
					m_controller.getRedPlayer()));
			setTile(StartingTile.BLUE_X, StartingTile.BLUE_Y,
					new StartingTile(
					StartingTile.BLUE_X, StartingTile.BLUE_Y,
					m_controller.getBluePlayer()));
			setTile(StartingTile.YELLOW_X, StartingTile.YELLOW_Y,
					new StartingTile(
					StartingTile.YELLOW_X, StartingTile.YELLOW_Y,
					m_controller.getYellowPlayer()));
			setTile(StartingTile.GREEN_X, StartingTile.GREEN_Y,
					new StartingTile(
					StartingTile.GREEN_X, StartingTile.GREEN_Y,
					m_controller.getGreenPlayer()));
		} catch (Exception e) {
			System.err.println(e);
			return false;
		}
		
		return true;
	}
	
	/**
	 * Generate the home areas
	 *
	 * @return true if successful, false otherwise
	 */
	private boolean generateHomeAreas() {
		m_redHome = new HomeArea(m_controller.getRedPlayer(), this);
		m_blueHome = new HomeArea(m_controller.getBluePlayer(), this);
		m_yellowHome = new HomeArea(m_controller.getYellowPlayer(), this);
		m_greenHome = new HomeArea(m_controller.getGreenPlayer(), this);
		
		return true;
	}
	
	/**
	 * Generate the starting areas
	 *
	 * @return true if successful, false otherwise
	 */
	private boolean generateStartingAreas() {
		m_redStart = new StartingArea(m_controller.getRedPlayer(), this);
		m_blueStart = new StartingArea(m_controller.getBluePlayer(), this);
		m_yellowStart = new StartingArea(m_controller.getYellowPlayer(), this);
		m_greenStart = new StartingArea(m_controller.getGreenPlayer(), this);
		
		return true;
	}

	public final static int BOARD_SIZE = 15;
	public static final int HOME_COLUMN_TILES = 6;
	
	private final int HOME_COLUMN_START_RG = 1;
	private final int HOME_COLUMN_START_BY = 9;
	private final int HOME_COLUMN_END_RG = 6;
	private final int HOME_COLUMN_END_BY = 14;
	private final int HOME_COLUMN = 7;
	
	
	private LudoController m_controller;
	private StartingArea m_redStart, m_blueStart, m_yellowStart, m_greenStart;
	private HomeArea m_redHome, m_blueHome, m_yellowHome, m_greenHome;
}
