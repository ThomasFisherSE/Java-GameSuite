/**
 * @file LudoAi.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see GameAi.java, LudoPlayer.java
 * @brief An AI that plays Ludo
 *
 * An AI that calculates its own moves to play a game of Ludo
 */

package ludo;

import java.util.ArrayList;
import java.util.Random;

import gamesuite.Dice;
import gamesuite.GameAi;

public class LudoAi extends LudoPlayer implements GameAi {
	
	/**
	 * The constructor for a Ludo AI
	 *  
	 * @param name the name given to the bot
	 * @param col the color of the ai player
	 * @param lc the ludo controller that is in charge of the game
	 */
	public LudoAi(String name, String col, LudoController lc) {
		super(lc, name, col);
		m_sleepTime = DEFAULT_SLEEP_TIME;
	}
	
	/**
	 * Set the time between moves to a certain interval
	 *  
	 * @param time the time between moves
	 * @return true if valid time, false otherwise
	 */
	public boolean setTime(double time) {
		if (time >= 0) {
			m_sleepTime = (int) (time * MILLISEC_IN_SEC);
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Make a move in the game
	 *  
	 * @return true if valid move, false otherwise
	 */
	public boolean makeMove() {
		int roll = getController().getDice().roll();
		generateMoves();
		Random rand = new Random();
		
		int attempts = 0;
		
		boolean validMove;
		
		getController().repaintAll();
		//Sleep here as computer simulates thinking about its move
		try {
			Thread.sleep(m_sleepTime);
		} catch (InterruptedException e) {
			System.err.println("Failed to put thread to sleep.");
		}
		
		if (needsSix() || roll == Dice.TOP_ROLL) {
			if (roll == Dice.TOP_ROLL && getBoard().getStartingArea(
					getColorAsString()).getAmount() != 0) {
				Piece piece;
				do {
					attempts++;
					piece = m_possibleMoves.get(rand.nextInt(
							m_possibleMoves.size()));
					validMove = piece.getLocation() instanceof StartingSlot;
					
					if (attempts > MAX_ATTEMPTS) {
						System.err.println("AI could not find a valid move");
						return false;
					}
				} while (!validMove);
				
				getController().getBoard().getStartingArea(
						getColorAsString()).remove(piece);
				getController().nextPlayer();
				return true;
			} else {
				System.out.println("Ai couldn't make a move, "
						+ "going to next player");
				getController().nextPlayer();
				return false;
			}
		}
		
		do {
			attempts++;
			validMove = m_possibleMoves.get(rand.nextInt(
					m_possibleMoves.size())).tryMove(roll);
			
			if (attempts > MAX_ATTEMPTS) {
				System.err.println("AI could not find a valid move");
				return false;
			}
		} while (!validMove);
		
		getController().nextPlayer();
		
		return true;
	}

	/**
	 * Generate the list of moves that can be made
	 *
	 * @return true if successful, false otherwise
	 */
	public boolean generateMoves() {
		try {
			m_possibleMoves.clear();
			
			for (Piece elem: getPieces()) {
				if (!elem.isHome()) {
					m_possibleMoves.add(elem);
				}
			}
			
			return true;
		} catch (Exception e) {
			System.err.println(e);
			return false;
		}
	}

	/**
	 * Run the AI
	 */
	public void run() {
		while (m_running) {
			try {
				if (getController().isOver()) {
					m_running = false;
				}
				
				if (getController().getNextPlayer().equals(this)) {
					makeMove();
					getController().repaintAll();
				}
			} catch (NullPointerException e) {
				System.out.println("AI waiting for initialisation..");
			}
			
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println(getColorAsString()+ " AI is stopping.");
	}
	
	private int m_sleepTime;
	private ArrayList<Piece> m_possibleMoves = new ArrayList<Piece>();
	private boolean m_running = true;
	
	private final int MILLISEC_IN_SEC = 1000;
	private final int DEFAULT_SLEEP_TIME = 3 * MILLISEC_IN_SEC;
	
	private final int MAX_ATTEMPTS = 20;
	
	public final static int DEFAULT_AI_SPEED = 2;
}
