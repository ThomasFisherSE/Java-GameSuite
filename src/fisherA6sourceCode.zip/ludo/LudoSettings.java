/**
 * @file LudoSettings.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see LudoController.java
 * @brief The settings for Ludo
 *
 * A settings area for creating a game of Ludo, including player details,
 * and AI settings.
 */

package ludo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class LudoSettings {
	
	/**
	 * Constructor for LudoSettings
	 */
	public LudoSettings() {
		displayGui();
	}
	
	/**
	 * Get the color of a player given their number
	 * 
	 * @param playerNumber the number of the player
	 * @return the color of the player as a string
	 */
	private String getColor(int playerNumber) {
		switch (playerNumber) {
			case PLAYER_ONE: return "red";
			case PLAYER_TWO: return "blue";
			case PLAYER_THREE: return "yellow";
			case PLAYER_FOUR: return "green";
			default: return "Color Error";
		}
	}
	
	/**
	 * Set the colors of the GUI for a particular player
	 * 
	 * @param playerNumber the number of the player
	 */
	private void setColors(int playerNumber) {
		/* Set the colors of the components for each
		 * player based on their color
		 * 
		 * The background color is set to the player's color
		 * 
		 * The forgeground color is set to the
		 * contrasting color of the background
		 */
		
		switch (playerNumber) {
			case 1: m_grpPlayerDetails[playerNumber].setBackground(Color.RED);
					m_lblName[playerNumber].setForeground(Color.GREEN);
					m_humanPlayer[playerNumber].setForeground(Color.GREEN);
					m_computerPlayer[playerNumber].setForeground(Color.GREEN);
					break;
				
			case 2: m_grpPlayerDetails[playerNumber].setBackground(Color.BLUE);
					m_lblName[playerNumber].setForeground(Color.ORANGE);
					m_humanPlayer[playerNumber].setForeground(Color.ORANGE);
					m_computerPlayer[playerNumber].setForeground(Color.ORANGE);
					break;
					
			case 3: m_grpPlayerDetails[playerNumber].setBackground(
						Color.YELLOW);
					m_lblName[playerNumber].setForeground(Color.MAGENTA);
					m_humanPlayer[playerNumber].setForeground(Color.MAGENTA);
					m_computerPlayer[playerNumber].setForeground(
							Color.MAGENTA);
					break;
				
			case 4: m_grpPlayerDetails[playerNumber].setBackground(
						Color.GREEN);
					m_lblName[playerNumber].setForeground(Color.RED);
					m_humanPlayer[playerNumber].setForeground(Color.RED);
					m_computerPlayer[playerNumber].setForeground(Color.RED);
					break;
		}
	}
	
	/**
	 * Start a new game given the current settings
	 * 
	 * @return true if the game can be started, false otherwise
	 */
	private boolean startGame() {
		m_anyAiPlayers = false;
		m_players = new LudoPlayer[LudoController.MAX_PLAYERS+1];
		
		for (int i = 1; i <= LudoController.MAX_PLAYERS; i++) {
			if (m_humanPlayer[i].isSelected()) {
				m_players[i] = new LudoPlayer(m_controller,
						m_txtName[i].getText(), getColor(i));
			} else if (m_computerPlayer[i].isSelected()) {
				m_anyAiPlayers = true;
				m_players[i] = new LudoAi(m_txtName[i].getText(),
						getColor(i), m_controller);
			} else {
				JOptionPane.showMessageDialog(null, 
						"Invalid player type selection.");
				return false;
			}
			
		}
		
		double aiSpeed;
		
		try {
			aiSpeed = Double.parseDouble(m_txtAiSpeed.getText());
		} catch (Exception e) {
			aiSpeed = -1;
		}
		
		if ((aiSpeed < 0 || aiSpeed > MAX_AI_SPEED) && m_anyAiPlayers) {
			JOptionPane.showMessageDialog(null, "The time between AI turns"
					+ " should be between 0 and 10 seconds.");
			return false;
		}
		
		m_controller = new LudoController(m_players, aiSpeed);
		m_frmSettings.dispose();
		
		return true;
	}
	
	/**
	 * Display the GUI
	 */
	private void displayGui() {
		m_frmSettings.setLayout(new BorderLayout());
		
		m_constraints.insets = new Insets(TOP_BOTTOM_INSETS,
				LEFT_RIGHT_INSETS, TOP_BOTTOM_INSETS, LEFT_RIGHT_INSETS);
		
		displayInstructions();
		displayPlayerInfo();
		displayExtraSettings();
		displayFrame();
		
		class EventHandler implements ActionListener {
			/**
			 * Implementation of abstract method inherited from ActionListener
			 * This method adds functionality to the buttons at the footer
			 * of game container
			 * @param e An ActionEvent 
			 */
        	public void actionPerformed(ActionEvent e) {
        		if (e.getSource().equals(m_btnStart)) {
        			startGame();
        		}
        	}
        }
		
		EventHandler handler = new EventHandler();
		m_btnStart.addActionListener(handler);
	}

	/**
	 * Display the instructions for the settings screen
	 */
	private void displayInstructions() {
		m_pnlInstructions.setLayout(new BorderLayout());
		m_pnlInstructions.setBackground(Color.WHITE);
		
		m_lblTitle.setHorizontalAlignment(JLabel.CENTER);
		m_lblTitle.setFont(new Font("Courier", Font.BOLD, TITLE_FONT_SIZE));
		m_pnlInstructions.add(m_lblTitle, BorderLayout.PAGE_START);
		
		m_lblInstructions.setHorizontalAlignment(JLabel.CENTER);
		m_lblInstructions.setText("Enter the details for each player below, "
				+ "then click 'Start Game' when you're ready to play!");
		m_lblInstructions.setFont(new Font("Courier", Font.BOLD,
				INSTRUCTIONS_FONT_SIZE));
		m_pnlInstructions.add(m_lblInstructions, BorderLayout.PAGE_END);
		
		m_frmSettings.add(m_pnlInstructions, BorderLayout.PAGE_START);
	}
	
	/**
	 * Display the main settings frame
	 */
	private void displayFrame() {
		m_frmSettings.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        m_frmSettings.setPreferredSize(new Dimension(
        		FRAME_WIDTH, FRAME_HEIGHT));
        m_frmSettings.setResizable(false);
        m_frmSettings.pack();
        m_frmSettings.setVisible(true);
	}
	
	/**
	 * Main method to create an instance of LudoSettings
	 * 
	 * @param args un-needed command line arguments
	 */
	public static void main(String[] args) {
		new LudoSettings();
	}
	
	/**
	 * Display the player info part of the settings
	 */
	private void displayPlayerInfo() {
		m_pnlPlayers.setLayout(new GridBagLayout());
		m_pnlPlayers.setBackground(Color.WHITE);
		
		for (int i = 1; i <= LudoController.MAX_PLAYERS; i++) {
			m_constraints.gridx = 0;
			m_constraints.gridy = 0;
			
			m_grpPlayerDetails[i] = new JPanel();
			m_grpPlayerDetails[i].setLayout(new GridBagLayout());
			
			m_playerTitle[i] = new JLabel("Player " + i + ":");
			m_playerTitle[i].setBackground(Color.WHITE);
			m_playerTitle[i].setBorder(BorderFactory.createLineBorder(
					Color.BLACK));
			m_playerTitle[i].setOpaque(true);
				
			m_grpPlayerDetails[i].add(m_playerTitle[i], m_constraints);
			m_constraints.gridy++;
			
			m_lblName[i] = new JLabel("Name: ");
			Font font = m_lblName[i].getFont();
			m_lblName[i].setForeground(Color.WHITE);
			m_lblName[i].setFont(new Font(font.getFontName(),
					Font.BOLD, font.getSize()));
			m_grpPlayerDetails[i].add(m_lblName[i], m_constraints);
			m_constraints.gridx++;
			
			m_txtName[i] = new JTextField(CHARACTERS_IN_NAME);
			m_txtName[i].setText("Player " + i);
			m_grpPlayerDetails[i].add(m_txtName[i], m_constraints);
			m_constraints.gridy++;
			
			m_constraints.gridx=0;
			m_humanPlayer[i] = new JRadioButton("Human");
			m_humanPlayer[i].setOpaque(false);
			m_humanPlayer[i].setSelected(true);
			m_grpPlayerDetails[i].add(m_humanPlayer[i], m_constraints);
			m_constraints.gridx++;
			m_computerPlayer[i] = new JRadioButton("Bot");
			m_computerPlayer[i].setOpaque(false);
			m_grpPlayerDetails[i].add(m_computerPlayer[i], m_constraints);
			
			m_playerTypes[i] = new ButtonGroup();
			m_playerTypes[i].add(m_humanPlayer[i]);
			m_playerTypes[i].add(m_computerPlayer[i]);
			
			m_grpPlayerDetails[i].setBorder(BorderFactory.createLineBorder(
					Color.BLACK));
			
			if (i <= PLAYER_COLUMNS) {
				m_constraints.gridx = i;
				m_constraints.gridy = PLAYERS_ROW;
			} else {
				m_constraints.gridx = i - PLAYER_COLUMNS;
				m_constraints.gridy = PLAYERS_ROW+1;
			}
			
			setColors(i);
			
			m_pnlPlayers.add(m_grpPlayerDetails[i], m_constraints);
		}
		
		m_frmSettings.add(m_pnlPlayers, BorderLayout.CENTER);
	}
	
	/**
	 * Display extra settings
	 */
	private void displayExtraSettings() {
		m_pnlExtraSettings.setLayout(new BorderLayout());
		m_pnlExtraSettings.setBackground(Color.WHITE);
		m_pnlButtons.setBackground(Color.WHITE);
		m_pnlAiSettings.setBackground(Color.WHITE);
		
		m_txtAiSpeed.setColumns(AI_SPEED_COLUMNS);
		m_pnlAiSettings.add(m_lblAiSpeed);
		m_pnlAiSettings.add(m_txtAiSpeed);
		m_pnlButtons.add(m_btnStart);
		m_pnlExtraSettings.add(m_pnlAiSettings, BorderLayout.PAGE_START);
		m_pnlExtraSettings.add(m_pnlButtons, BorderLayout.PAGE_END);
		m_frmSettings.add(m_pnlExtraSettings,BorderLayout.PAGE_END);
	}
	
	private LudoPlayer[] m_players;
	private LudoController m_controller;
	
	private JFrame m_frmSettings = new JFrame("Ludo Settings");
	private GridBagConstraints m_constraints = new GridBagConstraints();
	
	//Arrays for player details input components - index is the player number
	private JPanel[] m_grpPlayerDetails =
			new JPanel[LudoController.MAX_PLAYERS+1];
	private JLabel[] m_lblName = 
			new JLabel[LudoController.MAX_PLAYERS+1];
	private JTextField[] m_txtName = 
			new JTextField[LudoController.MAX_PLAYERS+1];
	private JLabel[] m_playerTitle = 
			new JLabel[LudoController.MAX_PLAYERS+1];
	private ButtonGroup[] m_playerTypes = 
			new ButtonGroup[LudoController.MAX_PLAYERS+1];
	private JRadioButton[] m_humanPlayer = 
			new JRadioButton[LudoController.MAX_PLAYERS+1];
	private JRadioButton[] m_computerPlayer = 
			new JRadioButton[LudoController.MAX_PLAYERS+1];
	
	//Frame components
	private JLabel m_lblTitle = new JLabel("Welcome to Ludo!");
	private JLabel m_lblInstructions = new JLabel();
	private JPanel m_pnlInstructions = new JPanel();
	private JPanel m_pnlPlayers = new JPanel();
	private JPanel m_pnlExtraSettings = new JPanel();
	private JPanel m_pnlButtons = new JPanel();
	private JPanel m_pnlAiSettings = new JPanel();
	private JTextField m_txtAiSpeed = 
			new JTextField("" + LudoAi.DEFAULT_AI_SPEED);
	private JLabel m_lblAiSpeed = 
			new JLabel("Time between AI turns (secs): ");
	private JButton m_btnStart = new JButton("Start Game");
	private boolean m_anyAiPlayers;
	
	private final int FRAME_HEIGHT = 340;
	private final int FRAME_WIDTH = 675;
	private final int CHARACTERS_IN_NAME = 20;
	private final int PLAYERS_ROW = 1;
	private final int PLAYER_COLUMNS = 2;
	private final int TOP_BOTTOM_INSETS = 3;
	private final int LEFT_RIGHT_INSETS = 3;
	private final int TITLE_FONT_SIZE = 36;
	private final int INSTRUCTIONS_FONT_SIZE = 12;
	private final int AI_SPEED_COLUMNS = 5;
	private final int MAX_AI_SPEED = 10;
	private final int PLAYER_ONE = 1, PLAYER_TWO = 2, 
			PLAYER_THREE = 3, PLAYER_FOUR = 4;
}


