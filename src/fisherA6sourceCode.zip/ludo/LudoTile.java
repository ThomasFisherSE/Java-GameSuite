/**
 * @file LudoTile.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see Tile.java, LudoBoard.java
 * @brief Any tile in a game of Ludo
 *
 * A Ludo Tile, with behaviours required to be part of a Ludo Board
 */

package ludo;

import gamesuite.Tile;

public abstract class LudoTile extends Tile {
	
	/**
	 * Constructor for a LudoTile
	 * 
	 * @param x the x coordinate of the tile
	 * @param y the y coordinate of the tile
	 */
	public LudoTile(int x, int y) {
		super(WIDTH, HEIGHT);
		m_x = x;
		m_y = y;
	}
	
	/**
	 * Get the x coordinate of the tile
	 * 
	 * @return the x coordinate of the tile
	 */
	public int getX() {
		return m_x;
	}
	
	/**
	 * Get the y coordinate of the tile
	 * 
	 * @return the y coordinate of the tile
	 */
	public int getY() {
		return m_y;
	}
	
	/**
	 * Get the piece occupying this tile
	 * 
	 * @return the piece occupying this tile
	 */
	public Piece getPiece() {
		return m_occupyingPiece;
	}
	
	/**
	 * Check if the tile has a piece occupying it
	 * 
	 * @return true if there is a piece on this tile, false otherwise
	 */
	public boolean hasPiece() {
		return m_occupied;
	}
	
	/**
	 * Add a piece to this tile
	 * 
	 * @return true if added successfully, false otherwise
	 */
	public boolean addPiece(Piece playerPiece) {
		if (!m_occupied) {
			m_occupyingPiece = playerPiece;
			m_occupied = true;
		} else {
			System.out.println("Tile occupied.");
			return false;
		}
		
		return true;
	}
	
	/**
	 * Replace the piece on this tile with a new piece
	 * 
	 * @param newPiece the new piece to put in this tile
	 * @return true if replaced successfully, false otherwise
	 */
	public boolean replacePiece(Piece newPiece) {
		if (m_occupyingPiece != null) {
			LudoPlayer occupyingPlayer = m_occupyingPiece.getPlayer();
			LudoBoard board = occupyingPlayer.getController().getBoard();
			
			StartingArea startingArea = board.getStartingArea(
					occupyingPlayer.getColorAsString());
			
			startingArea.add(m_occupyingPiece);
			m_occupyingPiece = newPiece;
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Remove a piece from this tile
	 * 
	 * @param playerPiece the piece to remove
	 * @return true if the piece was removed successfully, false otherwise
	 */
	public boolean removePiece(Piece playerPiece) {
		if (m_occupyingPiece != null) {
			if (!m_occupyingPiece.equals(playerPiece)) {
				System.out.println("Couldn't remove piece from tile as "
						+ "it isn't currently occupying that tile.");
				return false;
			}
		}
		
		if (!m_occupied) {
			return false;
		} else {
			m_occupyingPiece = null;
			m_occupied = false;
		}
		
		return true;
	}
	
	private Piece m_occupyingPiece;
	
	private boolean m_occupied = false;
	private int m_x;
	private int m_y;
	
	public final static int WIDTH = 30;
	public final static int HEIGHT = 30;
}
