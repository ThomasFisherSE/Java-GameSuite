/**
 * @file LudoPlayer.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see Player.java, LudoAi.java
 * @brief A player (Human or AI) of Ludo
 *
 * A player with all the information required to be a player of Ludo
 */

package ludo;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import gamesuite.Player;

public class LudoPlayer extends Player {
	
	/**
	 * Constructor for a LudoPlayer
	 * 
	 * @param lc the controller of the game
	 * @param name the name of the player
	 * @param col the color of the player
	 */
	public LudoPlayer(LudoController lc, String name, String col) {
		super(name);
		this.m_controller = lc;
		this.m_color = col;
		
		for (int i = 0; i < NUMBER_OF_PIECES; i++) {
			m_pieces.add(new Piece(this));
		}
	}
	
	/**
	 * Get the number of pieces this player has home
	 * 
	 * @return the number of pieces the player has home
	 */
	public int getAmountHome() {
		return getBoard().getHomeArea(m_color).getAmount();
	}
	
	/**
	 * Get the number of pieces this player has in the starting area
	 * 
	 * @return the number of pieces the player has in the starting area
	 */
	public int getAmountAtStart() {
		return getBoard().getStartingArea(m_color).getAmount();
	}
	
	/**
	 * Get the board the player is playing on
	 * 
	 * @return the board the game is being played on
	 */
	public LudoBoard getBoard() {
		return m_board;
	}
	
	/**
	 * Get the color of the player
	 * 
	 * @return the color of the player
	 */
	public Color getColor() {
		if (m_color.equals("red")) {
			return Color.RED;
		} else if (m_color.equals("blue")) {
			return Color.BLUE;
		} else if (m_color.equals("yellow")) {
			return Color.YELLOW;
		} else if (m_color.equals("green")) {
			return Color.GREEN;
		} else {
			System.err.println("Player was set to an invalid color.");
			return Color.BLACK;
		}
	}
	
	/**
	 * Get the controller of the game
	 * 
	 * @return the controller of the game being played by this player
	 */
	public LudoController getController() {
		return m_controller;
	}
	
	/**
	 * Get this player's pieces
	 * 
	 * @return the pieces owned by this player
	 */
	public ArrayList<Piece> getPieces() {
		return m_pieces;
	}
	
	/**
	 * Get the color of the player as a string
	 * 
	 * @return the color of the player in a string format
	 */
	public String getColorAsString() {
		return m_color;
	}
	
	/**
	 * Check if the player needs a six to move
	 * 
	 * @return true if the player needs a six, false otherwise
	 */
	public boolean needsSix() {
		StartingArea myStart = getBoard().getStartingArea(m_color);
		HomeArea myHome = getBoard().getHomeArea(m_color);
		
		return NUMBER_OF_PIECES - myStart.getAmount() == myHome.getAmount();
	}
	
	/**
	 * Get the player ready to start
	 */
	public void prepareForStart() {
		for (Piece elem: m_pieces) {
			m_controller.getBoard().getStartingArea(m_color).add(elem);
		}
	}
	
	/**
	 * State that this player is finished
	 */
	public void finish() {
		m_controller.addFinishedPlayer(this);
	}
	
	/**
	 * Render each of this player's pieces
	 * 
	 * @param g the Graphics object used to render
	 */
	public void renderPieces(Graphics g) {
		for (Piece elem: m_pieces) {
			elem.render(g);
		}
	}
	
	/**
	 * Set the controller of the game
	 * 
	 * @param ludoController the new controller of the game
	 */
	public void setController(LudoController ludoController) {
		m_controller = ludoController;
		m_board = ludoController.getBoard();
		
		for (Piece elem: m_pieces) {
			elem.setController(ludoController);
		}
	}
	
	private String m_color;
	private ArrayList<Piece> m_pieces = new ArrayList<Piece>();
	private LudoController m_controller;
	private LudoBoard m_board;
	
	public static final int NUMBER_OF_PIECES = 4;

	
}
