/**
 * @file HomeColumnTile.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see LudoTile.java
 * @brief A home column tile
 *
 * A tile in the home column of a particular player.
 */

package ludo;

import java.awt.Graphics;
import java.net.URL;

import javax.swing.ImageIcon;

public class HomeColumnTile extends LudoTile {
	/**
	 * Constructor for a home column tile
	 *  
	 * @param x the x coordinate of the tile
	 * @param y the y coordinate of the tile
	 * @param player the player the tile belongs to
	 */
	public HomeColumnTile(int x, int y, LudoPlayer player) {
		super(x, y);
		
		m_player = player;
		
		URL url = getClass().getResource("/images/ludo/" 
		+ m_player.getColorAsString() + "Ludo.png");
		
		if (url != null) {
			m_homeColumnIcon = new ImageIcon(url);
		} else {
			System.err.println("Player color invalid when creating"
					+ " HomeColumnTile.\n"
					+ "Player's color is: " + player.getColorAsString());
		}
		
	}

	/**
	 * Render the tile
	 *  
	 * @param g a Graphics object used to render
	 * @param xLocation the X coordinate to render at
	 * @param yLocation the Y coordinate to render at
	 */
	public void render(Graphics g, int x, int y) {
		g.drawImage(m_homeColumnIcon.getImage(),
					x * LudoTile.WIDTH,
					y * LudoTile.HEIGHT, 
					null);
	}
	
	private LudoPlayer m_player;
	private ImageIcon m_homeColumnIcon;
	
	public static int RED_ENTRY_X = 7, RED_ENTRY_Y = 0;
	public static int BLUE_ENTRY_X = 14, BLUE_ENTRY_Y = 7;
	public static int YELLOW_ENTRY_X = 7, YELLOW_ENTRY_Y = 14;
	public static int GREEN_ENTRY_X = 0, GREEN_ENTRY_Y = 7;
}
