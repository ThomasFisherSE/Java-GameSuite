/**
 * @file HomeArea.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see HomeAreaTile.java, LudoBoard.java
 * @brief The home area of a player
 *
 * A home area, where pieces that have finished the game go
 */


package ludo;

import java.util.ArrayList;

public class HomeArea {
	private LudoPlayer m_player;
	private ArrayList<Piece> m_pieces;
	private LudoBoard m_board;
	
	private final int FULL = 4;
	
	/**
	 * Constructor for a HomeArea
	 * 
	 * @param player the player the HomeArea belongs to
	 * @param board the board the HomeArea belongs to
	 */
	public HomeArea(LudoPlayer player, LudoBoard board) {
		m_board = board;
		m_player = player;
		m_pieces = new ArrayList<Piece>();
		generateTiles();
	}
	
	/**
	 * Get the number of pieces in the home area
	 * 
	 * @return the number of pieces in the home area
	 */
	public int getAmount() {
		return m_pieces.size();
	}
	
	/**
	 * Get this home area's player
	 * 
	 * @return the player the home area belongs to
	 */
	public LudoPlayer getPlayer() {
		return m_player;
	}
	
	/**
	 * Add a piece to the home area
	 * 
	 * @param piece the piece to add to the home area
	 */
	public void add(Piece piece) {
		m_pieces.add(piece);
		
		if (m_pieces.size() == FULL) {
			m_player.finish();
		}
	}
	
	/**
	 * Generate this home area's tiles
	 */
	private void generateTiles() {
		for (int i = START_X; i <= END_X; i++) {
			for (int j = START_Y; j <= END_Y; j++) {
				m_board.setTile(i,j, new HomeAreaTile(i,j));
			}
		}
	}
	
	public static final int START_X = 6;
	public static final int END_X = 8;
	public static final int START_Y = 6;
	public static final int END_Y = 8;
}
