/**
 * @file StartingSlot.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see StartingArea.java, StartingAreaTile.java, LudoTile.java
 * @brief A slot for a player piece in Ludo
 *
 * A tile within the starting area of a player in Ludo where one of
 * their piece can be held.
 */

package ludo;

import java.awt.Graphics;
import java.net.URL;

import javax.swing.ImageIcon;

public class StartingSlot extends StartingAreaTile {
	
	/**
	 * The constructor for a StartingSlot
	 *  
	 * @param x the x location of the tile
	 * @param y the y location of the tile
	 * @param player the player the starting slot belongs to
	 */
	public StartingSlot(int x, int y, LudoPlayer player) {
		super(x,y, player);
		
		m_player = player;
		
		try {
			URL url = getClass().getResource("/images/ludo/" + m_player.getColorAsString() + "Tile.png");
			m_startingSlotIcon = new ImageIcon(url);
		} catch (Exception e) {
			System.err.println("Could not assign correct graphic to " + m_player.getColorAsString() + " StartingSlot (" + x + "," + y + ")");
			m_startingSlotIcon = new ImageIcon(getClass().getResource("/images/ludo/noTexture.png"));
		}
	}
	
	/**
	 * Check if the slot is empty
	 *  
	 * @return true if the slot is empty, false otherwise
	 */
	public boolean isEmpty() {
		return m_empty;
	}
	
	/**
	 * Add a piece to the starting slot
	 *  
	 * @param piece the piece to add to the slot
	 * @return true if added successfully, false otherwise
	 */
	public boolean addPiece(Piece piece) {
		super.addPiece(piece);
		
		if (m_empty) {
			m_empty = false;
			return true;
		} else {
			System.err.println("Cannot add a piece to starting "
					+ "slot when it is already occupied.");
			return false;
		}
	}
	
	/**
	 * Remove a piece from the slot
	 *  
	 * @param piece the piece to remove
	 * @return true if removed successfully, false otherwise
	 */
	public boolean removePiece(Piece piece) {
		super.removePiece(piece);
		
		if (!m_empty) {
			m_empty = true;
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Render the tile
	 *  
	 * @param g a Graphics object used to render
	 * @param x the X coordinate to render at
	 * @param y the Y coordinate to render at
	 */
	public void render(Graphics g, int x, int y) {
		g.drawImage(m_startingSlotIcon.getImage(), 
				x * LudoTile.WIDTH,
				y * LudoTile.HEIGHT,
				null);
		
	}
	
	private ImageIcon m_startingSlotIcon;
	private boolean m_empty = true;
	private LudoPlayer m_player;
}
