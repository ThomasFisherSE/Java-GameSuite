/**
 * @file LudoController.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see LudoSettings.java
 * @brief The controller for a game of Ludo
 *
 * A controller in charge of each turn in a game of ludo, and responsible
 * for human player input to the game.
 */

package ludo;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Collections;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

import gamesuite.Dice;
import gamesuite.MainMenu;

public class LudoController implements MouseListener, ActionListener {
	
	/**
	 * Constructor for a LudoController
	 *
	 * @param players the players of the game
	 * @param aiSpeed the interval between the AI's turns
	 */
	public LudoController(LudoPlayer[] players, Double aiSpeed) {
		
		m_players = players;
		m_aiSpeed = aiSpeed;
		m_time = new Timer(TIMER_DELAY, this);
		m_time.start();
		
		m_dice = new Dice(Dice.SIX_SIDES);
		
		for (LudoPlayer elem: players) {
			if (elem != null) {
				elem.setController(this);
			}
		}
		
		m_red = players[PLAYER_ONE];
		m_blue = players[PLAYER_TWO];
		m_yellow = players[PLAYER_THREE];
		m_green = players[PLAYER_FOUR];
		
		setSounds();
		startAllAi();
		
		m_playerRotation.add(m_green);
		m_playerRotation.add(m_yellow);
		m_playerRotation.add(m_blue);
		m_playerRotation.add(m_red);
		
		m_board = new LudoBoard(this);
		
		m_green.setController(this);
		m_yellow.setController(this);
		m_blue.setController(this);
		m_red.setController(this);
		
		startGame();
		m_frmMain.setSize(GAME_WIDTH + INFO_WIDTH, GAME_HEIGHT);
		m_frmMain.setResizable(false);
		m_frmMain.setBackground(Color.WHITE);
		m_frmMain.setVisible(true);
	}
	
	/**
	 * Get the board the game's being played on
	 *
	 * @return the board the game is being played on
	 */
	public LudoBoard getBoard() {
		return m_board;
	}
	
	/**
	 * Get the red player
	 *
	 * @return the red player
	 */
	public LudoPlayer getRedPlayer() {
		return m_red;
	}
	
	/**
	 * Get the blue player
	 *
	 * @return the blue player
	 */
	public LudoPlayer getBluePlayer() {
		return m_blue;
	}
	
	/**
	 * Get the yellow player
	 *
	 * @return the yellow player
	 */
	public LudoPlayer getYellowPlayer() {
		return m_yellow;
	}
	
	/**
	 * Get the green player
	 *
	 * @return the green player
	 */
	public LudoPlayer getGreenPlayer() {
		return m_green;
	}
	
	/**
	 * Get the dice being used in this game
	 *
	 * @return the dice used in this game
	 */
	public Dice getDice() {
		return m_dice;
	}
	
	/**
	 * Get the player whose turn it is
	 * 
	 * @return the starting area of the player
	 */
	public LudoPlayer getNextPlayer() {
		return m_nextPlayer;
	}
	
	/**
	 * Get the instructions for Ludo
	 * 
	 * @return the instructions for the game of Ludo
	 */
	public String getInstructions() {
		return "Each player takes in turns to roll the dice. "
				+ "The highest roller begins the game. "
				+ "Turns go clockwise.\n\n"
				
				+ "To enter a token into play from "
				+ "its starting area to its starting square, a player must "
				+ "roll a 6.\n"
				+ "If the player has no tokens yet in play and does "
				+ "not roll a 6, the turn passes to the next player.\n"
				+ "Once a player has one or more tokens in play, he selects a "
				+ "token and moves it forward along the track the number of "
				+ "squares indicated by the die roll.\n"
				+ "Players must always move a token according to the die "
				+ "value rolled, and if no move is possible, pass their turn "
				+ "to the next player.\n\n"
				
				+ "When a player rolls a 6 he may choose to advance a token "
				+ "already in play, or alternatively, he may enter another "
				+ "staged token to its starting square.\n"
				+ " The rolling of a 6 earns the player an additional "
				+ "(bonus) roll in that turn.\n"
				+ "If the additional roll results in a 6 again, the player "
				+ "earns an additional bonus roll.\n"
				+ "If the third roll is also a 6, the player may not "
				+ "move a token and the turn immediately passes to "
				+ "the next player.\n\n"
				
				+ "A player may not end his move on a square he already "
				+ "occupies.\n"
				+ "If the advance of a token ends on a square "
				+ "occupied by an opponent's token, the opponent token is "
				+ "returned to its owner's yard.\n"
				+ "The returned token may only be reentered into play when "
				+ "the owner again rolls a 6.\n\n"
				
				+ "See: https://en.wikipedia.org/wiki/Ludo_(board_game)";
	}

	/**
	 * Get whether or not the game is over
	 *
	 * @return true if the game is over, false otherwise
	 */
	public boolean isOver() {
		return m_gameOver;
	}
	
	/**
	 * Set up the sounds used in the game
	 */
	private void setSounds() {
		AudioInputStream audioFile;
		try {
			audioFile = AudioSystem.getAudioInputStream(
					getClass().getResource("/sound/won.wav"));
			
			m_won = AudioSystem.getClip();
			m_won.open(audioFile);
		} catch (Exception e) {
			System.err.println("Could not load audio files.");
		}
		
	}
	
	/**
	 * Start all of the AI players
	 */
	private void startAllAi() {
		if (m_red instanceof LudoAi) {
			System.out.println("Starting red AI");
			((LudoAi) m_red).setTime(m_aiSpeed);
			new Thread((LudoAi) m_red).start();
		}
		
		if (m_blue instanceof LudoAi) {
			System.out.println("Starting blue AI");
			((LudoAi) m_blue).setTime(m_aiSpeed);
			new Thread((LudoAi) m_blue).start();
		}
		
		if (m_yellow instanceof LudoAi) {
			System.out.println("Starting yellow AI");
			((LudoAi) m_yellow).setTime(m_aiSpeed);
			new Thread((LudoAi) m_yellow).start();
		}
		
		if (m_green instanceof LudoAi) {
			System.out.println("Starting green AI");
			((LudoAi) m_green).setTime(m_aiSpeed);
			new Thread((LudoAi) m_green).start();
		}
	}
	
	/**
	 * Rotate to the next player
	 *
	 * @return the player whose turn it is after rotating the queue
	 */
	public LudoPlayer nextPlayer() {
		Collections.rotate(m_playerRotation, NEXT);
		m_nextPlayer = m_playerRotation.get(0);
		
		if (m_btnRoll != null) {
			if (m_nextPlayer instanceof LudoAi) {
				m_btnRoll.setEnabled(false);
			} else {
				m_btnRoll.setEnabled(true);
			}
		}
		
		System.out.println("Next player is " + m_nextPlayer.getColorAsString());
		return m_nextPlayer;
	}
	
	/**
	 * Start the game
	 */
	private void startGame() {
		m_red.prepareForStart();
		m_blue.prepareForStart();
		m_yellow.prepareForStart();
		m_green.prepareForStart();
		
		displayGame();
		displayInfo();
		m_nextPlayer = nextPlayer();
		
		m_frmMain.add(m_pnlGame);
		m_frmMain.setJMenuBar(myMenu());
		repaintAll();
	}
	
	/**
	 * Display the game panel
	 */
	private void displayGame() {
		m_pnlGame= new JPanel() {
			private static final long serialVersionUID = 1L;

			@Override
			public void paintComponent(Graphics g) {
				super.paintComponent(g);
				m_board.render(g);
				renderAllPlayerPieces(g);
			}
		};
		
		m_pnlGame.addMouseListener(this);
	}
	
	/**
	 * Display game UI info
	 */
	private void displayInfo() {
		initialiseStats();
		
		m_pnlInfo = new JPanel() {
			private static final long serialVersionUID = 1L;
			
			@Override
			public void paintComponent(Graphics g) {
				m_pnlInfo.removeAll();
				super.paintComponent(g);
				
				Font font = new Font("Courier", Font.BOLD, FONT_SIZE);
				
				// Positioning Values.
				int x = START_X;
				int y = START_Y;
				
				g.setFont(font);
				
				if (m_timePassed == null) {
					g.drawString("Time: 00:00:00", x, y);
				} else {
					g.drawString("Time: " + m_timePassed, x, y);
				}
				
				y+= Y_SPACING;
				
				if (m_nextPlayer != null) {
					g.setColor(Color.BLACK);
					g.drawString(m_nextPlayer.getUsername() + "'s turn.", x, y);
					y += Y_SPACING;
				}
				
				m_dice.render(g, x, y);
				
				y += Y_SPACING + Dice.SIZE;
				
				m_btnRoll.setBounds(x,y, ROLL_BUTTON_WIDTH, ROLL_BUTTON_HEIGHT);
				m_btnRoll.setBackground(m_nextPlayer.getColor());
				
				if (m_nextPlayer.getColor().equals(Color.BLUE) ||
						m_nextPlayer.getColor().equals(Color.RED)) {
					
					m_btnRoll.setForeground(Color.WHITE);
					
				} else {
					m_btnRoll.setForeground(Color.BLACK);
				}
				
				m_pnlInfo.add(m_btnRoll);
				
				y += Y_SPACING + ROLL_BUTTON_HEIGHT;
				
				createStatsPanel();
				
				m_pnlStats.setBounds(STATS_X, y, STATS_WIDTH, STATS_HEIGHT);
				m_pnlInfo.add(m_pnlStats);
				
				m_pnlInfo.setBackground(Color.WHITE);
			}
		};
		
		m_btnRoll = new JButton("Roll Dice");
		m_btnRoll.addActionListener(this);

		m_pnlInfo.setBounds(GAME_WIDTH, 0, INFO_WIDTH, INFO_HEIGHT);
		m_frmMain.getContentPane().add(m_pnlInfo);
		m_pnlInfo.setLayout(null);

		repaintAll();
	}
	
	/**
	 * Initialise the player stats
	 */
	private void initialiseStats() {
		m_pnlStats = new JPanel();
		m_pnlStats.setLayout(new BoxLayout(m_pnlStats, BoxLayout.PAGE_AXIS));
		m_pnlStats.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		m_pnlStats.setBackground(Color.WHITE);
		
		m_lblRedStatsTitle = new JLabel(m_red.getUsername() + ": ");
		m_lblBlueStatsTitle = new JLabel(m_blue.getUsername() + ": ");
		m_lblYellowStatsTitle = new JLabel(m_yellow.getUsername() + ": ");
		m_lblGreenStatsTitle = new JLabel(m_green.getUsername() + ": ");
		
		m_lblRedStart = new JLabel();
		m_lblBlueStart = new JLabel();
		m_lblYellowStart = new JLabel();
		m_lblGreenStart = new JLabel();
		
		m_lblRedHome = new JLabel();
		m_lblBlueHome = new JLabel();
		m_lblYellowHome = new JLabel();
		m_lblGreenHome = new JLabel();
	}
	
	/**
	 * Update the player stats to the latest information
	 */
	private void updateStats() {
		m_lblRedStart.setText("Start: " + m_red.getAmountAtStart());
		m_lblBlueStart.setText("Start: " + m_blue.getAmountAtStart());
		m_lblYellowStart.setText("Start: " + m_yellow.getAmountAtStart());
		m_lblGreenStart.setText("Start: " + m_green.getAmountAtStart());
		
		m_lblRedHome.setText("Home: " + m_red.getAmountHome());
		m_lblBlueHome.setText("Home: " + m_blue.getAmountHome());
		m_lblYellowHome.setText("Home: " + m_yellow.getAmountHome());
		m_lblGreenHome.setText("Home: " + m_green.getAmountHome());
		
	}
	
	/**
	 * Create a player statistics panel
	 */
	private void createStatsPanel() {
		m_pnlStats.removeAll();
		updateStats();
		m_pnlStats.add(m_lblRedStatsTitle);
		m_pnlStats.add(m_lblRedStart);
		m_pnlStats.add(m_lblRedHome);
		m_pnlStats.add(new JLabel("    "));
		m_pnlStats.add(m_lblBlueStatsTitle);
		m_pnlStats.add(m_lblBlueStart);
		m_pnlStats.add(m_lblBlueHome);
		m_pnlStats.add(new JLabel("    "));
		m_pnlStats.add(m_lblYellowStatsTitle);
		m_pnlStats.add(m_lblYellowStart);
		m_pnlStats.add(m_lblYellowHome);
		m_pnlStats.add(new JLabel("    "));
		m_pnlStats.add(m_lblGreenStatsTitle);
		m_pnlStats.add(m_lblGreenStart);
		m_pnlStats.add(m_lblGreenHome);
	}
	
	/**
	 * Render each of the players' pieces
	 *
	 * @param g the Graphics object used to render
	 */
	private void renderAllPlayerPieces(Graphics g) {
		m_red.renderPieces(g);
		m_blue.renderPieces(g);
		m_yellow.renderPieces(g);
		m_green.renderPieces(g);
	}
	
	/**
	 * Reset the game
	 */
	public void reset() {
		endGameEarly();
		m_frmMain.dispose();
		new LudoController(m_players, m_aiSpeed);
	}
	
	/**
	 * Repaint all GUI elements
	 */
	public void repaintAll() {
		try {
			m_pnlGame.repaint();
			m_pnlInfo.repaint();
			m_frmMain.repaint();
			m_frmMain.validate();
			m_pnlGame.validate();
			m_pnlInfo.validate();
		} catch (NullPointerException e) {
			System.out.println("Waiting for all GUI elements "
					+ "to be initialised");
		}
		
	}
	
	/**
	 * Create a JMenu for the game
	 *
	 * @return a menu of options for the game
	 */
	private JMenuBar myMenu() {
		JMenuBar menu = new JMenuBar();
		JMenu game = new JMenu("Game");
		
		m_newGame = new JMenuItem("New Game");
		m_newGame.addActionListener(this);
		m_settings = new JMenuItem("Settings");
		m_settings.addActionListener(this);
		m_mainMenu = new JMenuItem("Main Menu");
		m_mainMenu.addActionListener(this);
		m_exit = new JMenuItem("Exit");
		m_exit.addActionListener(this);
		
		game.add(m_newGame);
		game.add(m_settings);
		game.add(m_mainMenu);
		game.add(m_exit);
				
		JMenu help = new JMenu("Help");
		
		m_about = new JMenuItem("About");
		m_about.addActionListener(this);
		m_instructions = new JMenuItem("Instructions");
		m_instructions.addActionListener(this);
		
		help.add(m_about);
		help.add(m_instructions);
		menu.add(game);
		menu.add(help);
		
		return menu;
	}
	
	/**
	 * End the game without printing the winners
	 */
	private void endGameEarly() {
		m_gameOver = true;
	}
	
	/**
	 * Add a player to the list of finished players
	 *
	 * @param player the player to add to the list of finished players
	 */
	public void addFinishedPlayer(LudoPlayer player) {
		m_finishedPlayers.add(player);
		m_playerRotation.remove(player);
		
		if (m_finishedPlayers.size() == ALL_BUT_ONE_PLAYERS) {
			m_finishedPlayers.add(m_playerRotation.get(FIRST));
			endGame();
		}
	}
	
	/**
	 * Called on mouse event
	 * 
	 * @param event the mouse event that happened
	 */
	public void mouseClicked(MouseEvent event) {
		if (!m_gameOver) {
			int xPos = (int) Math.floor(event.getX() / 
					LudoTile.DEFAULT_TILE_WIDTH);
			int yPos = (int) Math.floor(event.getY() / 
					LudoTile.DEFAULT_TILE_HEIGHT);
			LudoTile tileClicked;
			
			if (!m_waitingForPlayer) {
				//Not the time to make a move, do nothing
				System.out.println("Waiting for dice roll.");
				return;
			}
			
			try {
				tileClicked = m_board.getTile(xPos, yPos);
			} catch (Exception e) {
				//Not a valid tile
				return;
			}
			
			if (tileClicked.hasPiece()) {
				
				if (tileClicked instanceof HomeAreaTile) {
					System.out.println("This piece is already home.");
					return;
				}
				
				if (!tileClicked.getPiece().getPlayer().equals(m_nextPlayer)) {
					System.out.println("Can't move other player's pieces.");
					return;
				}
				
				if (tileClicked instanceof StartingSlot) {
					if (m_latestRoll == Dice.TOP_ROLL) {
						if (!m_board.getStartingArea(
								m_nextPlayer.getColorAsString()).remove(
										tileClicked.getPiece())) {
							
							System.out.println("Can't remove a piece from the"
									+ " starting area if you already have a"
									+ " piece occupying your starting tile");
							
							return;
						}
					} else {
						System.out.println("Must roll a six to move a "
								+ "piece to the start.");
						return;
					}
				} else {
					if (!tileClicked.getPiece().tryMove(m_latestRoll)) {
						System.out.println("Can't move this piece, as it "
								+ "would collide with your own piece.");
						return;
					}
				}
		
				m_waitingForPlayer = false;
				
				//Unless a 6 was rolled, go to the next player.
				if (m_latestRoll != Dice.TOP_ROLL) {
					nextPlayer();
				}
			} else {
				System.out.println("No piece detected.");
			}
				
			repaintAll();
		}
	}

	/**
	 * Unused but included due to implements.
	 * 
	 * @param e unused MouseEvent
	 */
	@Override
	public void mouseEntered(MouseEvent arg0) {
		
	}

	/**
	 * Unused but included due to implements.
	 * 
	 * @param e unused MouseEvent
	 */
	@Override
	public void mouseExited(MouseEvent arg0) {
		
	}

	/**
	 * Unused but included due to implements.
	 * 
	 * @param e unused MouseEvent
	 */
	@Override
	public void mousePressed(MouseEvent arg0) {
		
	}

	/**
	 * Unused but included due to implements.
	 * 
	 * @param e unused MouseEvent
	 */
	@Override
	public void mouseReleased(MouseEvent arg0) {
		
	}

	/**
	 * An action is performed
	 * 
	 * @param event an ActionEvent describing what happened
	 */
	@Override
	public void actionPerformed(ActionEvent event) {
			
		if (event.getSource() == m_newGame) {
			reset();
		} else if (event.getSource() == m_settings) {
			endGameEarly();
			m_frmMain.getContentPane().removeAll();
			m_frmMain.getJMenuBar().setVisible(false);
			
			if (m_menu == null) {
				new LudoSettings();
				m_frmMain.dispose();
			} else {
				m_menu = new LudoSettings();
			}
		} else if (event.getSource() == m_mainMenu) {
			endGameEarly();
			m_frmMain.dispose();
			new MainMenu();
		} else if (event.getSource() == m_exit) {
			endGameEarly();
			System.exit(0);
			
		} else if (event.getSource() == m_about) {
			
			String author = "Author: Thomas Fisher";
			author += "Date created : 06/12/2015 \n";
			author += "Version : 3.0\n";
			author += "The game was part of an assignment and ";
			author += "is based on the famous game Ludo";
			JOptionPane.showMessageDialog(m_about,
											author,
											"About",
											JOptionPane.PLAIN_MESSAGE);
			
		} else if (event.getSource() == m_instructions) {
			
			JOptionPane.showMessageDialog(m_instructions,
											getInstructions(),
											"Ludo Instructions",
											JOptionPane.PLAIN_MESSAGE);

		} else if (event.getSource() == m_btnRoll) {
			if (!m_waitingForPlayer) {
				m_latestRoll = m_dice.roll();
				System.out.println(m_nextPlayer.getColorAsString() 
						+ " rolled a " + m_latestRoll); 
				
				if (m_nextPlayer.needsSix() && m_latestRoll != Dice.TOP_ROLL) {
					System.out.println("Need to roll a 6 to advance."
							+ " Skipping turn.");
					nextPlayer();
					m_waitingForPlayer = false;
				} else {
					m_waitingForPlayer = true;
				}
				
			} else {
				System.out.println("Cannot roll, waiting for player to move");
			}
			
			repaintAll();
		} else if (event.getSource() == m_time) {
			m_pnlInfo.repaint();
			
			m_secondsPlayed += m_time.getDelay() / TIMER_DELAY;
			
			if (m_secondsPlayed >= SECONDS_IN_MINUTE) {
				
				m_minutesPlayed = m_minutesPlayed + 1;
				m_secondsPlayed = 0;
				
				if (m_minutesPlayed >= MINUTES_IN_HOUR) {
					m_hoursPlayed = m_hoursPlayed + 1;
					m_minutesPlayed = 0;
				}
			}
			
			String hours = "" + m_hoursPlayed;
			String minutes = ""+ m_minutesPlayed;
			String seconds = "" + m_secondsPlayed;
			
			if (m_hoursPlayed < DOUBLE_DIGITS) {
				hours = "0" + hours;
			}
			
			if (m_minutesPlayed < DOUBLE_DIGITS) {
				minutes = "0" + minutes;
			}
			
			if (m_secondsPlayed < DOUBLE_DIGITS) {
				seconds = "0" + seconds;
			}
			
			m_timePassed = hours
							+ ":" 
							+ minutes
							+ ":" 
							+ seconds;
		}
	}
	
	/**
	 * End the game
	 */
	public void endGame() {
		m_won.loop(1);
		m_gameOver = true;
		m_time.stop();
		repaintAll();
		
		JOptionPane.showMessageDialog(m_frmMain,
				m_finishedPlayers.get(FIRST).getUsername() + " won the game!\n"
				+ m_finishedPlayers.get(SECOND).getUsername() + " came 2nd.\n"
				+ m_finishedPlayers.get(THIRD).getUsername() + " came 3rd.\n"
				+ m_finishedPlayers.get(FOURTH).getUsername() + " came 4th.",
				"Game Over",
				JOptionPane.PLAIN_MESSAGE);
	}
	
	private LudoSettings m_menu;
	private Dice m_dice;
	private LudoPlayer m_red, m_blue, m_yellow, m_green;
	private LudoBoard m_board;
	private JFrame m_frmMain = new JFrame("Ludo");
	private JPanel m_pnlGame, m_pnlInfo, m_pnlStats;
	private JLabel m_lblRedStatsTitle, m_lblBlueStatsTitle,
		m_lblYellowStatsTitle, m_lblGreenStatsTitle;
	private JLabel m_lblRedHome, m_lblBlueHome,
		m_lblYellowHome, m_lblGreenHome;
	private JLabel m_lblRedStart, m_lblBlueStart,
		m_lblYellowStart, m_lblGreenStart;
	private JButton m_btnRoll;
	private boolean m_gameOver = false;
	private ArrayList<LudoPlayer> m_playerRotation =
			new ArrayList<LudoPlayer>();
	private LudoPlayer m_nextPlayer;
	private LudoPlayer[] m_players;
	private ArrayList<LudoPlayer> m_finishedPlayers =
			new ArrayList<LudoPlayer>();
	
	private int m_latestRoll;
	private boolean m_waitingForPlayer = false;
	
	private JMenuItem m_newGame;
	private JMenuItem m_settings;
	private JMenuItem m_mainMenu;
	private JMenuItem m_exit;
	private JMenuItem m_about;
	private JMenuItem m_instructions;
	
	private Clip m_won;
	
	private Timer m_time;
	private long m_hoursPlayed;
	private long m_minutesPlayed;
	private long m_secondsPlayed;
	private String m_timePassed;
	private Double m_aiSpeed;
	
	public static final int MAX_PLAYERS = 4;
	private final int SPACING = 55;
	private final int ROLL_BUTTON_HEIGHT = 30, ROLL_BUTTON_WIDTH = 100;
	private final int STATS_X = 10, STATS_WIDTH = 150, STATS_HEIGHT = 250;
	
	private final int GAME_WIDTH = LudoBoard.BOARD_SIZE * 
			LudoTile.WIDTH;
	
	private final int GAME_HEIGHT = LudoBoard.BOARD_SIZE *
			LudoTile.HEIGHT + SPACING;
	
	private final int INFO_WIDTH = 175,
			INFO_HEIGHT = GAME_HEIGHT;
	
	private final int NEXT = 1;
	private final int PLAYER_ONE = 1, PLAYER_TWO = 2,
			PLAYER_THREE = 3, PLAYER_FOUR = 4;
	private final int FONT_SIZE = 12;
	private final int START_X = 35, START_Y = 10;
	private final int Y_SPACING = 10;
	private final int ALL_BUT_ONE_PLAYERS = 3;
	private final int FIRST = 0, SECOND = 1, THIRD = 2, FOURTH = 3;
	private final int TIMER_DELAY = 1000;
	private final int SECONDS_IN_MINUTE = 60, MINUTES_IN_HOUR = 60;
	private final int DOUBLE_DIGITS = 10;
}
