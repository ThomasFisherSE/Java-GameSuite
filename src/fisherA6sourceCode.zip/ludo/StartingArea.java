/**
 * @file StartingArea.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see StartingAreaTile.java, LudoBoard.java
 * @brief The starting area of a player
 *
 * The starting area of a player consisting of StartingAreaTile objects
 */

package ludo;

import java.util.ArrayList;

public class StartingArea {
	
	/**
	 * The constructor for a StartingArea
	 * 
	 * @param player the player the starting area belongs to
	 * @param board the board the game is being played on
	 */
	public StartingArea(LudoPlayer player, LudoBoard board) {
		this.m_board = board;
		this.m_player = player;
		m_pieces = new ArrayList<Piece>();
		generateTiles();
	}
	
	/**
	 * Get the number of pieces in the starting area
	 *  
	 * @return the number of pieces in the starting area
	 */
	public int getAmount() {
		return m_pieces.size();
	}
	
	/**
	 * Check if the starting area is full
	 *  
	 * @return true if full, false otherwise
	 */
	public boolean isFull() {
		System.out.println("Starting area size: " + m_pieces.size());
		return m_pieces.size() == FULL;
	}

	/**
	 * Find a free slot in the starting area
	 *  
	 * @return the next free slot in the starting area
	 */
	public LudoTile getFreeSlot() {
		for (StartingSlot slot: m_startingSlots) {
			if (slot.isEmpty()) {
				return slot;
			}
		}
		
		System.err.println("No free starting area slots found.");
		return null;
	}
	
	/**
	 * Get the slot occupied by a particular piece
	 *  
	 * @param piece the piece to find the slot occupied by
	 * @return the slot occupied by the piece
	 */
	public LudoTile getSlotOccupiedBy(Piece piece) {
		for (StartingSlot slot: m_startingSlots) {
			if (slot.getPiece() != null) {
				if (slot.getPiece().equals(piece)) {
					return slot;
				}
			}
		}
		
		System.err.println("Couldn't find slot occupied by that piece");
		return null;
	}
	
	/**
	 * Add a piece to the starting area
	 *  
	 * @param piece the piece to add
	 * @return true if added successfully, false otherwise
	 */
	public boolean add(Piece piece) {
		System.out.println(m_player.getColorAsString() 
				+ " starting area size before adding: " + m_pieces.size());
		
		if (m_pieces.size() < FULL) {
			if (getFreeSlot() != null) {
				piece.moveToStartingArea();
				m_pieces.add(piece);
				System.out.println("Size after adding: " + m_pieces.size());
			} else {
				System.err.println("No free starting area slots.");
				return false;
			}
			
			System.out.println("Piece added to starting area pieces array");
			
			return true;
		} else {
			System.err.println("Starting area full.");
			return false;
		}
	}
	
	/**
	 * Remove a piece from the starting area
	 *  
	 * @param pieceToRemove the piece to remove
	 * @return true if removed successfully, false otherwise
	 */
	public boolean remove(Piece pieceToRemove) {
		LudoTile oldLocation = pieceToRemove.getLocation();
		
		if (pieceToRemove.moveToStart()) {
			oldLocation.removePiece(pieceToRemove);
			
			m_pieces.remove(pieceToRemove);
			
			System.out.println("Starting area size: " + m_pieces.size());
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Generate the tiles in the starting area
	 *  
	 * @return true if generated successfully, false otherwise
	 */
	private boolean generateTiles() {
		if (m_player.getColorAsString().equals("red")) {
			generateRedStartArea();
			return true;
		} else if (m_player.getColorAsString().equals("blue")) {
			generateBlueStartArea();
			return true;
		} else if (m_player.getColorAsString().equals("yellow")) {
			generateYellowStartArea();
			return true;
		} else if (m_player.getColorAsString().equals("green")) {
			generateGreenStartArea();
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Generate the red starting area tiles
	 */
	private void generateRedStartArea() {
		for (int i = START_OF_RED_X; i <= END_OF_RED_X; i++) {
			for (int j = START_OF_RED_Y; j <= END_OF_RED_Y; j++) {
				m_board.setTile(i,j, new StartingAreaTile(i, j, m_player));
			}
		}
		
		m_startingSlots.add(new StartingSlot(RED_SLOT1_X,
				RED_SLOT1_Y, m_player));
		m_startingSlots.add(new StartingSlot(RED_SLOT2_X,
				RED_SLOT2_Y, m_player));
		m_startingSlots.add(new StartingSlot(RED_SLOT3_X,
				RED_SLOT3_Y, m_player));
		m_startingSlots.add(new StartingSlot(RED_SLOT4_X,
				RED_SLOT4_Y, m_player));
		
		m_board.setTile(RED_SLOT1_X, RED_SLOT1_Y,
				m_startingSlots.get(FIRST_SLOT));
		m_board.setTile(RED_SLOT2_X, RED_SLOT2_Y,
				m_startingSlots.get(SECOND_SLOT));
		m_board.setTile(RED_SLOT3_X, RED_SLOT3_Y,
				m_startingSlots.get(THIRD_SLOT));
		m_board.setTile(RED_SLOT4_X, RED_SLOT4_Y,
				m_startingSlots.get(FOURTH_SLOT));
	}
	
	/**
	 * Generate the blue starting area tiles
	 */
	private void generateBlueStartArea() {
		for (int i = START_OF_BLUE_X; i <= END_OF_BLUE_X; i++) {
			for (int j = START_OF_BLUE_Y; j <= END_OF_BLUE_Y; j++) {
				m_board.setTile(i,j, new StartingAreaTile(i, j, m_player));
			}
		}
		
		m_startingSlots.add(new StartingSlot(BLUE_SLOT1_X,
				BLUE_SLOT1_Y, m_player));
		m_startingSlots.add(new StartingSlot(BLUE_SLOT2_X,
				BLUE_SLOT2_Y, m_player));
		m_startingSlots.add(new StartingSlot(BLUE_SLOT3_X,
				BLUE_SLOT3_Y, m_player));
		m_startingSlots.add(new StartingSlot(BLUE_SLOT4_X,
				BLUE_SLOT4_Y, m_player));
		
		m_board.setTile(BLUE_SLOT1_X, BLUE_SLOT1_Y,
				m_startingSlots.get(FIRST_SLOT));
		m_board.setTile(BLUE_SLOT2_X, BLUE_SLOT2_Y,
				m_startingSlots.get(SECOND_SLOT));
		m_board.setTile(BLUE_SLOT3_X, BLUE_SLOT3_Y,
				m_startingSlots.get(THIRD_SLOT));
		m_board.setTile(BLUE_SLOT4_X, BLUE_SLOT4_Y,
				m_startingSlots.get(FOURTH_SLOT));
	}
	
	/**
	 * Generate the yellow starting area tiles
	 */
	private void generateYellowStartArea() {
		for (int i = START_OF_YELLOW_X; i <= END_OF_YELLOW_X; i++) {
			for (int j = START_OF_YELLOW_Y; j <= END_OF_YELLOW_Y; j++) {
				m_board.setTile(i,j, new StartingAreaTile(i,j, m_player));
			}
		}
		
		m_startingSlots.add(new StartingSlot(YELLOW_SLOT1_X,
				YELLOW_SLOT1_Y, m_player));
		m_startingSlots.add(new StartingSlot(YELLOW_SLOT2_X,
				YELLOW_SLOT2_Y, m_player));
		m_startingSlots.add(new StartingSlot(YELLOW_SLOT3_X,
				YELLOW_SLOT3_Y, m_player));
		m_startingSlots.add(new StartingSlot(YELLOW_SLOT4_X,
				YELLOW_SLOT4_Y, m_player));
		
		m_board.setTile(YELLOW_SLOT1_X, YELLOW_SLOT1_Y,
				m_startingSlots.get(FIRST_SLOT));
		m_board.setTile(YELLOW_SLOT2_X, YELLOW_SLOT2_Y,
				m_startingSlots.get(SECOND_SLOT));
		m_board.setTile(YELLOW_SLOT3_X, YELLOW_SLOT3_Y,
				m_startingSlots.get(THIRD_SLOT));
		m_board.setTile(YELLOW_SLOT4_X, YELLOW_SLOT4_Y,
				m_startingSlots.get(FOURTH_SLOT));
	}
	
	/**
	 * Generate the green starting area tiles
	 */
	private void generateGreenStartArea() {
		for (int i = START_OF_GREEN_X; i <= END_OF_GREEN_X; i++) {
			for (int j = START_OF_GREEN_Y; j <= END_OF_GREEN_Y; j++) {
				m_board.setTile(i,j, new StartingAreaTile(i, j, m_player));
			}
		}
		
		m_startingSlots.add(new StartingSlot(GREEN_SLOT1_X,
				GREEN_SLOT1_Y, m_player));
		m_startingSlots.add(new StartingSlot(GREEN_SLOT2_X,
				GREEN_SLOT2_Y, m_player));
		m_startingSlots.add(new StartingSlot(GREEN_SLOT3_X,
				GREEN_SLOT3_Y, m_player));
		m_startingSlots.add(new StartingSlot(GREEN_SLOT4_X,
				GREEN_SLOT4_Y, m_player));
		
		m_board.setTile(GREEN_SLOT1_X, GREEN_SLOT1_Y,
				m_startingSlots.get(FIRST_SLOT));
		m_board.setTile(GREEN_SLOT2_X, GREEN_SLOT2_Y,
				m_startingSlots.get(SECOND_SLOT));
		m_board.setTile(GREEN_SLOT3_X, GREEN_SLOT3_Y,
				m_startingSlots.get(THIRD_SLOT));
		m_board.setTile(GREEN_SLOT4_X, GREEN_SLOT4_Y,
				m_startingSlots.get(FOURTH_SLOT));
	}
	
	private LudoPlayer m_player;
	private ArrayList<Piece> m_pieces;
	private LudoBoard m_board;
	private ArrayList<StartingSlot> m_startingSlots =
			new ArrayList<StartingSlot>();
	
	private final int FULL = 4;
	
	public static int START_OF_GREEN_X = 0;
	public static int START_OF_GREEN_Y = 0;
	public static int END_OF_GREEN_X = 5;
	public static int END_OF_GREEN_Y = 5;
	public static int START_OF_RED_X = 9;
	public static int START_OF_RED_Y = START_OF_GREEN_Y;
	public static int END_OF_RED_X = 14;
	public static int END_OF_RED_Y = END_OF_GREEN_Y;
	public static int START_OF_BLUE_X = START_OF_RED_X;
	public static int START_OF_BLUE_Y = 9;
	public static int END_OF_BLUE_X = END_OF_RED_X;
	public static int END_OF_BLUE_Y = 14;
	public static int START_OF_YELLOW_X = START_OF_GREEN_X;
	public static int START_OF_YELLOW_Y = START_OF_BLUE_Y;
	public static int END_OF_YELLOW_X = END_OF_GREEN_X;
	public static int END_OF_YELLOW_Y = END_OF_BLUE_Y;
	
	private final int FIRST_SLOT = 0, SECOND_SLOT = 1,
			THIRD_SLOT = 2, FOURTH_SLOT = 3;
	
	/* Starting slot locations */
	public static int GREEN_SLOT1_X = 1, GREEN_SLOT1_Y = 1;
	public static int GREEN_SLOT2_X = GREEN_SLOT1_X+3,
			GREEN_SLOT2_Y = GREEN_SLOT1_Y;
	public static int GREEN_SLOT3_X = GREEN_SLOT1_X,
			GREEN_SLOT3_Y = GREEN_SLOT1_Y+3;
	public static int GREEN_SLOT4_X = GREEN_SLOT2_X,
			GREEN_SLOT4_Y = GREEN_SLOT3_Y;
	
	public static int RED_SLOT1_X = 10, RED_SLOT1_Y = GREEN_SLOT1_Y;
	public static int RED_SLOT2_X = RED_SLOT1_X+3,
			RED_SLOT2_Y = GREEN_SLOT2_Y;
	public static int RED_SLOT3_X = RED_SLOT1_X,
			RED_SLOT3_Y = GREEN_SLOT3_Y;
	public static int RED_SLOT4_X = RED_SLOT2_X,
			RED_SLOT4_Y = GREEN_SLOT4_Y;
	
	public static int BLUE_SLOT1_X = RED_SLOT1_X,
			BLUE_SLOT1_Y = 10;
	public static int BLUE_SLOT2_X = BLUE_SLOT1_X+3,
			BLUE_SLOT2_Y = BLUE_SLOT1_Y;
	public static int BLUE_SLOT3_X = BLUE_SLOT1_X,
			BLUE_SLOT3_Y = BLUE_SLOT1_Y+3;
	public static int BLUE_SLOT4_X = BLUE_SLOT2_X,
			BLUE_SLOT4_Y = BLUE_SLOT3_Y;
	
	public static int YELLOW_SLOT1_X = GREEN_SLOT1_X,
			YELLOW_SLOT1_Y = BLUE_SLOT1_Y;
	public static int YELLOW_SLOT2_X = YELLOW_SLOT1_X+3,
			YELLOW_SLOT2_Y = YELLOW_SLOT1_Y;
	public static int YELLOW_SLOT3_X = YELLOW_SLOT1_X,
			YELLOW_SLOT3_Y = YELLOW_SLOT1_Y+3;
	public static int YELLOW_SLOT4_X = YELLOW_SLOT2_X,
			YELLOW_SLOT4_Y = YELLOW_SLOT3_Y;
	
}
