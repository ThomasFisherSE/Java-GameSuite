/**
 * @file Piece.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see LudoController.java, LudoAi.java
 * @brief A piece in a game of Ludo
 *
 * A piece including all the information on how to move in Ludo
 */

package ludo;

import java.awt.Color;
import java.awt.Graphics;
import java.net.URL;

import javax.swing.ImageIcon;

import gamesuite.Tile;

public class Piece {
	
	/**
	 * The constructor for a Piece
	 * 
	 * @param player the player the piece belongs to
	 */
	public Piece(LudoPlayer player) {
		m_player = player;
		m_controller = player.getController();
		
		URL url = null;
		
		try {
			url = getClass().getResource("/images/ludo/" + 
		m_player.getColorAsString() + "Piece.png");
		} catch (NullPointerException e) {
			System.err.println("Could not find resource: " + 
		m_player.getColorAsString() + "Piece.png");
		}
		
		if (url != null) {
			m_pieceIcon = new ImageIcon(url);
		} else {
			System.err.println("Player color invalid when creating piece.\n"
					+ "Player's color is: " + player.getColorAsString());
		}
	}
	
	/**
	 * Get the location of the piece
	 * 
	 * @return the tile that the piece is currently on
	 */
	public LudoTile getLocation() {
		return m_location;
	}
	
	/**
	 * Get the player who owns this piece
	 * 
	 * @return the player who owns the piece
	 */
	public LudoPlayer getPlayer() {
		return m_player;
	}
	
	/**
	 * Check if the piece is home
	 * 
	 * @return true if the piece is home, false otherwise
	 */
	public boolean isHome() {
		return m_home;
	}
	
	/**
	 * Get the next tile the piece should go to
	 * 
	 * @return the next tile the piece should go to
	 */
	public LudoTile getNextTile() {
		LudoTile checkTile = null;
		
		if (m_location instanceof HomeAreaTile || m_goingBackwards) {
			homeColumnMoveBackwards();
			return m_board.getTile(m_xLocation, m_yLocation);
		}
		
		if (m_location instanceof HomeColumnTile) {
			homeColumnMoveForwards();
			return m_board.getTile(m_xLocation, m_yLocation);
		}
		
		checkTile = checkEntryToHomeColumn();
		
		if (checkTile != null) {
			return checkTile;
		}
		
		if (m_yLocation == TURN_ROW3) {
			if (m_xLocation == TURN_COLUMN2) {
				m_xLocation++;
				m_yLocation--;
			} else if (m_xLocation == TURN_COLUMN7) {
				m_yLocation++;
			} else {
				m_xLocation++;
			}
			
			return m_board.getTile(m_xLocation, m_yLocation);
		}
		
		if (m_yLocation == TURN_ROW4) {
			if (m_xLocation == TURN_COLUMN1) {
				m_yLocation--;
			} else if (m_xLocation == TURN_COLUMN7) {
				m_yLocation++;
			}
			
			return m_board.getTile(m_xLocation, m_yLocation);
		}
		
		if (m_yLocation == TURN_ROW5) {
			if (m_xLocation == TURN_COLUMN1) {
				m_yLocation--;
			} else if (m_xLocation == TURN_COLUMN6) {
				m_xLocation--;
				m_yLocation++;
			} else {
				m_xLocation--;
			}
			
			return m_board.getTile(m_xLocation, m_yLocation);
		}
		
		if (m_xLocation == TURN_COLUMN3) {
			if (m_yLocation == TURN_ROW1) {
				m_xLocation++;
			} else if (m_yLocation == TURN_ROW6) {
				m_xLocation--;
				m_yLocation--;
			} else {
				m_yLocation--;
			}
			
			return m_board.getTile(m_xLocation, m_yLocation);
		}
		
		if (m_xLocation == TURN_COLUMN4) {
			if (m_yLocation == TURN_ROW1) {
				m_xLocation++;
			} else if (m_yLocation == TURN_ROW7) {
				m_xLocation--;
			}
			
			return m_board.getTile(m_xLocation, m_yLocation);
		}
		
		if (m_xLocation == TURN_COLUMN5) {
			if (m_yLocation == TURN_ROW2) {
				m_xLocation++;
				m_yLocation++;
			} else if (m_yLocation == TURN_ROW7) {
				m_xLocation--;
			} else {
				m_yLocation++;
			}
			
			return m_board.getTile(m_xLocation, m_yLocation);
		}
		
		return null;
	}
	
	/**
	 * Move the piece a certain distance around the board
	 * 
	 * @param distance the distance to move
	 * @return true if the move was successful, false otherwise
	 */
	private boolean move(int distance) {
		for (int i = 0; i < distance; i++) {
			if (!moveForward(distance-i)) {
				return false;
			}
		}
		
		m_goingBackwards = false;
		
		return true;
	}
	
	/**
	 * Simulate moving a piece a certain distance around the board
	 * 
	 * @param spaces the number of spaces to try moving
	 * @return true if the piece was moved successfully, false otherwise
	 */
	public boolean tryMove(int spaces) {
		LudoTile nextTileClone = m_nextTile;
		Tile[][] tilesClone = m_board.getTiles().clone();
		int xClone = m_xLocation;
		int yClone = m_yLocation;
		
		if (!move(spaces)) {
			m_nextTile = nextTileClone;
			m_xLocation = xClone;
			m_yLocation = yClone;
			m_board.setTileArray(tilesClone);
			updateLocation();
			System.out.println("Simulated move resulted in self-collision");
			return false;
		} else {
			return true;
		}
	}
	
	/**
	 * Move the piece forward
	 * 
	 * @param spacesLeft the number of spaces left to move forward
	 * @return true if moved forward successfully, false otherwise
	 */
	private boolean moveForward(int spacesLeft) {
		m_nextTile = getNextTile();
		
		if (m_nextTile == null) {
			return false;
		}
		
		if (spacesLeft == LAST_MOVE) {
			if (m_nextTile.hasPiece() && 
					!(m_nextTile instanceof HomeAreaTile)) {
				if (m_nextTile.getPiece().getPlayer().equals(m_player)) {
					System.out.println("This move would result in "
							+ "colliding with your own piece.");
					return false;
				}
				
				System.out.println("Removing " 
						+ m_nextTile.getPiece().getPlayer().getColorAsString() 
						+ "'s piece");
				m_nextTile.replacePiece(this);
			}
			
			if (m_nextTile instanceof HomeAreaTile) {
				m_board.getHomeArea(getPlayer().getColorAsString()).add(this);
				m_home = true;
			}
		}
		
		updateLocation();
		
		return true;
	}
	
	/**
	 * Move backwards through the home column
	 * 
	 * @return true if moved successfully, false otherwise
	 */
	private boolean homeColumnMoveBackwards() {
		if (m_player.getColor().equals(Color.RED)) {
			m_yLocation--;
		} else if (m_player.getColor().equals(Color.BLUE)) {
			m_xLocation++;
		} else if (m_player.getColor().equals(Color.YELLOW)) {
			m_yLocation++;
		} else if (m_player.getColor().equals(Color.GREEN)) {
			m_xLocation--;
		}
		
		m_goingBackwards = true;
		return true;
	}
	
	/**
	 * Move forwards through the home column
	 * 
	 * @return true if moved successfully, false otherwise
	 */
	private boolean homeColumnMoveForwards() {
		if (m_player.getColor().equals(Color.RED)) {
			m_yLocation++;
		} else if (m_player.getColor().equals(Color.BLUE)) {
			m_xLocation--;
		} else if (m_player.getColor().equals(Color.YELLOW)) {
			m_yLocation--;
		} else if (m_player.getColor().equals(Color.GREEN)) {
			m_xLocation++;
		}
		
		return true;
	}
	
	/**
	 * Move the piece into a home column if necessary
	 * 
	 * @return the tile the piece was calculated to be at after moving
	 */
	private LudoTile checkEntryToHomeColumn() {
		if (m_player.getColorAsString().equals("red")) {
			if (m_xLocation == HomeColumnTile.RED_ENTRY_X &&
					m_yLocation == HomeColumnTile.RED_ENTRY_Y) {
				
				m_yLocation++;
				
				return m_controller.getBoard().getTile(
						m_xLocation,
						m_yLocation);
				
			}
		} else if (m_player.getColorAsString().equals("blue")) {
			if (m_xLocation == HomeColumnTile.BLUE_ENTRY_X &&
					m_yLocation == HomeColumnTile.BLUE_ENTRY_Y) {
				
				m_xLocation--;
				
				return m_controller.getBoard().getTile(
						m_xLocation,
						m_yLocation);
				
			}
		} else if (m_player.getColorAsString().equals("yellow")) {
			if (m_xLocation == HomeColumnTile.YELLOW_ENTRY_X &&
					m_yLocation == HomeColumnTile.YELLOW_ENTRY_Y) {
				
				m_yLocation--;
				
				return m_controller.getBoard().getTile(
						m_xLocation,
						m_yLocation);
				
			}
		} else if (m_player.getColorAsString().equals("green")) {
			if (m_xLocation == HomeColumnTile.GREEN_ENTRY_X &&
					m_yLocation == HomeColumnTile.GREEN_ENTRY_Y) {
				
				m_xLocation++;
				
				return m_controller.getBoard().getTile(
						m_xLocation,
						m_yLocation);
			}
		}
		
		return null;
	}
	
	
	
	/**
	 * Update the location of the piece based on its new coordinates
	 */
	private void updateLocation() {
		if (m_location != null) {
			if (m_location.getPiece() != null) {
				m_location.removePiece(this);
			}
		}
		
		m_location = m_board.getTile(m_xLocation, m_yLocation);
		m_location.addPiece(this);
	}
	
	/**
	 * Set the controller of the game to a new controller
	 * 
	 * @param lc the new controller of the game
	 */
	public void setController(LudoController lc) {
		m_controller = lc;
		m_board = m_controller.getBoard();
	}
	
	/**
	 * Move the piece to the start
	 * 
	 * @return true if moved successfully, false otherwise
	 */
	public boolean moveToStart() {
		if (m_nextTile.hasPiece()) {
			if (m_nextTile.getPiece().getPlayer().equals(getPlayer())) {
				return false;
			} else {
				System.out.println("Removing " + m_nextTile.getPiece()
					.getPlayer().getColorAsString() + "'s piece");
				m_board.getStartingArea(m_nextTile.getPiece().getPlayer()
						.getColorAsString()).add(m_nextTile.getPiece());
				m_nextTile.replacePiece(this);
			}
		}
		
		if (m_player.getColorAsString().equals("red")) {
			m_xLocation = StartingTile.RED_X;
			m_yLocation = StartingTile.RED_Y;
		} else if (m_player.getColorAsString().equals("blue")) {
			m_xLocation = StartingTile.BLUE_X;
			m_yLocation = StartingTile.BLUE_Y;
		} else if (m_player.getColorAsString().equals("yellow")) {
			m_xLocation = StartingTile.YELLOW_X;
			m_yLocation = StartingTile.YELLOW_Y;
		} else if (m_player.getColorAsString().equals("green")) {
			m_xLocation = StartingTile.GREEN_X;
			m_yLocation = StartingTile.GREEN_Y;
		}
		
		updateLocation();
		
		return true;
	}
	
	/**
	 * Move the piece to the starting area
	 * 
	 * @return true if moved successfully, false otherwise
	 */
	public boolean moveToStartingArea() {
		if (m_player.getColorAsString().equals("red")) {
			StartingArea redStartingArea = m_controller.getBoard()
					.getStartingArea("red");
			m_xLocation = redStartingArea.getFreeSlot().getX();
			m_yLocation = redStartingArea.getFreeSlot().getY();
		} else if (m_player.getColorAsString().equals("blue")) {
			StartingArea blueStartingArea = m_controller.getBoard()
					.getStartingArea("blue");
			m_xLocation = blueStartingArea.getFreeSlot().getX();
			m_yLocation = blueStartingArea.getFreeSlot().getY();
		} else if (m_player.getColorAsString().equals("yellow")) {
			StartingArea yellowStartingArea = m_controller.getBoard()
					.getStartingArea("yellow");
			m_xLocation = yellowStartingArea.getFreeSlot().getX();
			m_yLocation = yellowStartingArea.getFreeSlot().getY();
		} else if (m_player.getColorAsString().equals("green")) {
			StartingArea greenStartingArea = m_controller.getBoard()
					.getStartingArea("green");
			m_xLocation = greenStartingArea.getFreeSlot().getX();
			m_yLocation = greenStartingArea.getFreeSlot().getY();
		}
		
		updateLocation();
		
		if (m_player.getColor().equals(Color.RED)) {
			m_nextTile = m_board.getTile(StartingTile.RED_X,
					StartingTile.RED_Y);
		} else if (m_player.getColor().equals(Color.BLUE)) {
			m_nextTile = m_board.getTile(StartingTile.BLUE_X,
					StartingTile.BLUE_Y);
		} else if (m_player.getColor().equals(Color.YELLOW)) {
			m_nextTile = m_board.getTile(StartingTile.YELLOW_X,
					StartingTile.YELLOW_Y);
		} else if (m_player.getColor().equals(Color.GREEN)) {
			m_nextTile = m_board.getTile(StartingTile.GREEN_X,
					StartingTile.GREEN_Y);
		}
		
		System.out.println(m_player.getColorAsString() 
				+ " piece moved to starting area.");
		
		return true;
	}
	
	/**
	 * Render the piece
	 *  
	 * @param g a Graphics object used to render
	 * @param x the X coordinate to render at
	 * @param y the Y coordinate to render at
	 */
	public void render(Graphics g) {
		g.drawImage(m_pieceIcon.getImage(), 
					m_xLocation * LudoTile.WIDTH,
					m_yLocation * LudoTile.HEIGHT,
					null);
	}
	
	private LudoPlayer m_player;
	private LudoTile m_location;
	private ImageIcon m_pieceIcon;
	private int m_xLocation;
	private int m_yLocation;
	private LudoController m_controller;
	private LudoBoard m_board;
	private LudoTile m_nextTile;
	private boolean m_home = false;
	private boolean m_goingBackwards = false;
	
	private final int TURN_COLUMN1 = 0, TURN_COLUMN2 = 5, TURN_COLUMN3 = 6,
			TURN_COLUMN4 = 7, TURN_COLUMN5 = 8,
			TURN_COLUMN6 = 9, TURN_COLUMN7 = 14;
	
	private final int TURN_ROW1 = 0, TURN_ROW2 = 5, TURN_ROW3 = 6,
			TURN_ROW4 = 7, TURN_ROW5 = 8, TURN_ROW6 = 9, TURN_ROW7 = 14;
	
	private final int LAST_MOVE = 1;
}
