/**
 * @file HomeAreaTile.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see HomeArea.java
 * @brief A tile in a Home Area
 *
 * A tile in the home area of a player, used for setting appropriate graphics
 * and detecting when a player is in a home area
 */

package ludo;

import java.awt.Graphics;
import java.net.URL;

import javax.swing.ImageIcon;

public class HomeAreaTile extends LudoTile {

	/**
	 * Constructor for a HomeAreaTile
	 * 
	 * @param x the x coordinate of the tile
	 * @param y the y coordinate of the tile
	 */
	public HomeAreaTile(int x, int y) {
		super(x,y);
		
		try {
			m_homeIcon = assignImageIcon(x,y);
		} catch (Exception e) {
			System.err.println("Could not assign correct graphic"
					+ " to HomeAreaTile (" + x + "," + y + ")");
			m_homeIcon = new ImageIcon(getClass().getResource(
					"/images/ludo/noTexture.png"));
		}
		
	}
	
	/**
	 * Assign the image icon to the tile
	 * 
	 * @param x the x coordinate of the tile
	 * @param y the y coordinate of the tile
	 * @return the image icon of the tile
	 */
	private ImageIcon assignImageIcon(int x, int y) {
		URL url = null;
		
		if (x == LEFT_X) {
			if (y == TOP_Y) {
				url = getClass().getResource("/images/ludo/HomeTopLeft.png");
			} else if (y == MIDDLE_Y) {
				url = getClass().getResource("/images/ludo/greenHome.png");
			} else if (y == BOTTOM_Y) {
				url = getClass().getResource(
						"/images/ludo/HomeBottomLeft.png");
			}
		} else if (x == MIDDLE_X) {
			if (y == TOP_Y) {
				url = getClass().getResource("/images/ludo/redHome.png");
			} else if (y == MIDDLE_Y) {
				url = getClass().getResource("/images/ludo/HomeCentre.png");
			} else if (y == BOTTOM_Y) {
				url = getClass().getResource("/images/ludo/yellowHome.png");
			}
		} else if (x == RIGHT_X) {
			if (y == TOP_Y) {
				url = getClass().getResource("/images/ludo/HomeTopRight.png");
			} else if (y == MIDDLE_Y) {
				url = getClass().getResource("/images/ludo/blueHome.png");
			} else if (y == BOTTOM_Y) {
				url = getClass().getResource(
						"/images/ludo/HomeBottomRight.png");
			}
		}
		
		return new ImageIcon(url);
	}

	/**
	 * Render the tile
	 *  
	 * @param g a Graphics object used to render
	 * @param xLocation the X coordinate to render at
	 * @param yLocation the Y coordinate to render at
	 */
	public void render(Graphics g, int xLocation, int yLocation) {
		g.drawImage(m_homeIcon.getImage(), 
				xLocation * LudoTile.WIDTH,
				yLocation * LudoTile.HEIGHT,
				null);
	}

	private ImageIcon m_homeIcon;
	
	private final int LEFT_X = 6, MIDDLE_X = LEFT_X+1, RIGHT_X = MIDDLE_X+1;
	private final int TOP_Y = 6, MIDDLE_Y = TOP_Y+1, BOTTOM_Y = MIDDLE_Y+1;
}
