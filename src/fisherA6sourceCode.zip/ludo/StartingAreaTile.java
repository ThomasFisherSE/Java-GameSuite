/**
 * @file StartingAreaTile.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see StartingArea.java, LudoTile.java
 * @brief A starting area tile
 *
 * A tile within the starting area of a particular player in Ludo
 */

package ludo;

import java.awt.Graphics;
import java.net.URL;

import javax.swing.ImageIcon;

public class StartingAreaTile extends LudoTile {

	/**
	 * Constructor for a StartingAreaTile
	 *  
	 * @param x the x coordinate of the tile
	 * @param y the y coordinate of the tile
	 * @param player the player the starting area belongs to
	 */
	public StartingAreaTile(int x, int y, LudoPlayer player) {
		super(x,y);
		m_player = player;
		
		URL url = getClass().getResource("/images/ludo/" 
				+ m_player.getColorAsString() + "Home.png");
		m_startingAreaIcon = new ImageIcon(url);
	}
	
	/**
	 * Render the tile
	 *  
	 * @param g a Graphics object used to render
	 * @param xLocation the X coordinate to render at
	 * @param yLocation the Y coordinate to render at
	 */
	public void render(Graphics g, int xLocation, int yLocation) {
		g.drawImage(m_startingAreaIcon.getImage(), 
				xLocation * LudoTile.WIDTH,
				yLocation * LudoTile.HEIGHT,
				null);
	}

	private LudoPlayer m_player;
	private ImageIcon m_startingAreaIcon;
}
