/**
 * @file StartingTile.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see LudoTile.java, StartingArea.java
 * @brief A starting tile
 *
 * The first tile a piece goes to from the starting area in Ludo
 */

package ludo;

import java.awt.Graphics;
import java.net.URL;

import javax.swing.ImageIcon;

public class StartingTile extends LudoTile {
	
	/**
	 * Constructor for a StartingTile
	 *  
	 * @param x the x coordinate of the tile
	 * @param y the y coordinate of the tile
	 * @param player the player the starting tile belongs to
	 */
	public StartingTile(int x, int y, LudoPlayer player) {
		super(x,y);
		m_player = player;
		
		URL url = getClass().getResource("/images/ludo/" 
				+ m_player.getColorAsString() + "Ludo.png");
		
		if (url != null) {
			m_startingIcon = new ImageIcon(url);
		} else {
			System.err.println("Player color invalid when"
					+ " creating StartingTile.\n"
					+ "Player's color is: " + player.getColorAsString());
		}
	}

	/**
	 * Render the tile
	 *  
	 * @param g a Graphics object used to render
	 * @param x the X coordinate to render at
	 * @param y the Y coordinate to render at
	 */
	public void render(Graphics g, int x, int y) {
		g.drawImage(m_startingIcon.getImage(), 
					x * LudoTile.WIDTH,
					y * LudoTile.HEIGHT,
					null);
	}
	
	private LudoPlayer m_player;
	private ImageIcon m_startingIcon;
	
	public static final int RED_X = 8, BLUE_X = 13, 
			YELLOW_X = 6, GREEN_X = 1;
	
	public static final int RED_Y = 1, BLUE_Y = 8,
			YELLOW_Y = 13, GREEN_Y = 6;
}
