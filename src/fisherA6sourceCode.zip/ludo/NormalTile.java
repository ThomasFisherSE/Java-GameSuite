/**
 * @file NormalTile.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see Tile.java
 * @brief A Normal Ludo Tile
 *
 * A normal, blank tile in a game of ludo, where there is no special behaviour
 */

package ludo;

import java.awt.Graphics;
import java.net.URL;

import javax.swing.ImageIcon;

public class NormalTile extends LudoTile {
	
	/**
	 * Constructor for a NormalTile
	 * 
	 * @param x the x coordinate of the tile
	 * @param y the y coordinate of the tile
	 */
	public NormalTile(int x, int y) {
		super(x,y);
		
		URL url = getClass().getResource("/images/ludo/ludoBlank.png");
		m_normalIcon = new ImageIcon(url);
	}
	
	/**
	 * Render the tile
	 *  
	 * @param g a Graphics object used to render
	 * @param x the X coordinate to render at
	 * @param y the Y coordinate to render at
	 */
	public void render(Graphics g, int x, int y) {
		g.drawImage(m_normalIcon.getImage(), 
					x * LudoTile.WIDTH,
					y * LudoTile.HEIGHT,
					null);
	}
	
	private ImageIcon m_normalIcon;
}
