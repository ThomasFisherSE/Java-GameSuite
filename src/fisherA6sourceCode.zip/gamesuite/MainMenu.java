/**
 * @file MainMenu.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see LudoMain.java, KablewieMain.java
 * @brief The main menu of the game suite
 *
 * The main menu, where a game to play can be chosen from
 */

package gamesuite;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.net.URL;
import javax.swing.*;
import kablewie.KablewieMain;
import ludo.LudoSettings;

public class MainMenu {
	
	/**
	 * Main method, create an instance of MainMenu
	 * 
	 * @param args un-needed command line arguments
	 */
	public static void main(String[] args) {
		new MainMenu();
	}
	
	/**
	 * Constructor for a main menu
	 */
	public MainMenu() {
		m_font = new Font("Courier", Font.BOLD, TITLE_FONT_SIZE);
		
		// Display the menu
		display();
		
		// Repaint the frame so it displays the menu
		m_frmMain.pack();
		m_frmMain.setResizable(false);
		m_frmMain.validate();
		m_frmMain.repaint();
	}
	
	/**
	 * Create a panel and add this to the main frame.
	 */
	public void display() {
		
		m_frmMain = new JFrame("Deluxe Game Suite");
		m_frmMain.setLayout(new BorderLayout());
		
		m_frmMain.getContentPane().setBackground(Color.WHITE);
		m_frmMain.setVisible(true);
		
		URL url = getClass().getResource("/images/logo.png");
		ImageIcon logo = new ImageIcon(url);
		JLabel lblLogo = new JLabel(logo);
		m_frmMain.add(lblLogo, BorderLayout.PAGE_START);
		
		JLabel lblInfo = new JLabel("Which game would you like to play?");
		lblInfo.setHorizontalAlignment(JLabel.CENTER);
		lblInfo.setFont(m_font);
		m_frmMain.add(lblInfo, BorderLayout.CENTER);
		
		JPanel pnlGames = new JPanel();
		pnlGames.setBackground(Color.WHITE);
		
		JButton btnKablewie = new JButton("Kablewie");
		btnKablewie.setBackground(Color.WHITE);
		pnlGames.add(btnKablewie);
		
		JButton btnLudo = new JButton("Ludo");
		btnLudo.setBackground(Color.WHITE);
		pnlGames.add(btnLudo);
		
		m_frmMain.add(pnlGames, BorderLayout.PAGE_END);
		
		class EventHandler implements ActionListener {
			/**
			 * Implementation of abstract method inherited from ActionListener
			 * This method adds functionality to the buttons at the footer
			 * of game container
			 * @param e An ActionEvent 
			 */
        	public void actionPerformed(ActionEvent e) {
        		if (e.getSource().equals(btnKablewie)) {
        			m_frmMain.dispose();
        			new KablewieMain();
        		} else if (e.getSource().equals(btnLudo)) {
        			m_frmMain.dispose();
        			new LudoSettings();
        		}
        	}
        }
		
		EventHandler handler = new EventHandler();
		btnKablewie.addActionListener(handler);	
		btnLudo.addActionListener(handler);
	}

	/**
	 * Called on KeyRelease, start the game if
	 * its the enter key.
	 * @param e the KeyEvent
	 */
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			
		}
	}
	
	/**
	 * Unused but included due to implements.
	 * @param e Unused KeyEvent
	 */
	public void keyPressed(KeyEvent e) {

	}
	
	/**
	 * Unused but included due to implements.
	 * @param e Unused KeyEvent
	 */
	public void keyTyped(KeyEvent e) {

	}
	
	/**
	 * Called if the user clicks on the start game button.
	 * @param arg0 the MouseEvent
	 */
	public void mouseClicked(MouseEvent arg0) {
		
	}
	
	/**
	 * Unused but included due to implements.
	 * @param arg0 Unused MouseEvent
	 */
	public void mouseEntered(MouseEvent arg0) {

	}
	
	/**
	 * Unused but included due to implements.
	 * @param arg0 Unused MouseEvent
	 */
	public void mouseExited(MouseEvent arg0) {

	}
	
	/**
	 * Unused but included due to implements.
	 * @param arg0 Unused MouseEvent
	 */
	public void mousePressed(MouseEvent arg0) {

	}
	
	/**
	 * Unused but included due to implements.
	 * @param arg0 Unused MouseEvent
	 */
	public void mouseReleased(MouseEvent arg0) {

	}

	private final int TITLE_FONT_SIZE = 19;
	
	private Font m_font;
	private JFrame m_frmMain;
	
}

