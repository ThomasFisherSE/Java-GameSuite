/**
 * @file Dice.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @brief A dice used in games
 *
 * A dice that simulates getting a random number in games
 */

package gamesuite;

import java.awt.Graphics;
import java.net.URL;
import java.util.concurrent.ThreadLocalRandom;
import javax.swing.ImageIcon;

public class Dice {
	
	/**
	 * Constructor for a dice
	 * 
	 * @param maxRoll the maximum roll allowed on the dice
	 */
	public Dice(int maxRoll) {
		URL url = getClass().getResource("/images/ludo/dice6.png");
		
		if (url != null) {
			m_diceIcon = new ImageIcon(url);
		} else {
			System.err.println("Couldn't load dice image");
			m_diceIcon = new ImageIcon(getClass().getResource(
					"/images/ludo/noTexture.png"));
		}
		
		NUMBER_GENERATOR_MAX = maxRoll + 1;
	}
	
	/**
	 * Render the dice
	 *  
	 * @param g a Graphics object used to render
	 * @param x the X coordinate to render at
	 * @param y the Y coordinate to render at
	 */
	public void render(Graphics g, int x, int y) {
		g.drawImage(m_diceIcon.getImage(), 
					x, y,
					null);
	}
	
	/**
	 * Roll the dice by calculating a random number in the range of the dice
	 * 
	 * @return the number rolled by the dice
	 */
	public int roll() {
		int rolled = ThreadLocalRandom.current().nextInt(
				NUMBER_GENERATOR_MIN, NUMBER_GENERATOR_MAX);
		
		URL url = getClass().getResource(
				"/images/ludo/dice" + rolled + ".png");
		
		if (url != null) {
			m_diceIcon = new ImageIcon(url);
		} else {
			System.err.println("Couldn't load dice image");
			m_diceIcon = new ImageIcon(getClass().getResource(
					"/images/ludo/noTexture.png"));
		}
		
		return rolled;
	}
	
	private ImageIcon m_diceIcon;
	
	private final int NUMBER_GENERATOR_MAX;
	private final int NUMBER_GENERATOR_MIN = 1;
	
	public static final int TOP_ROLL = 6;
	public static final int SIX_SIDES = 6;
	public static final int SIZE = 100;
}
