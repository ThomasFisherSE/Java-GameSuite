/**
 * @file Board.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see Tile.java, LudoBoard.java, KablewieBoard.java
 * @brief A game board
 *
 * A game board that can be used by many different 2D games
 */

package gamesuite;

import java.awt.Graphics;

public class Board {
	/**
	 * Constructor for a board
	 * 
	 * @param boardRows the number of rows the board has
	 * @param boardColumns the number of columns the board has
	 */
	public Board(int boardRows, int boardColumns) {
		m_rows = boardRows;
		m_columns = boardColumns;
		m_tiles = new Tile[m_columns][m_rows];
	}
	
	/**
	 * Get the number of columns in the board
	 * 
	 * @return the number of columns the board has
	 */
	public int getColumns() {
		return m_columns;
	}
	
	/**
	 * Get the number of rows in the board
	 * 
	 * @return the number of rows the board has
	 */
	public int getRows() {
		return m_rows;
	}
	
	/**
	 * Get the tiles in a board
	 * 
	 * @return the tiles in the board
	 */
	public Tile[][] getTiles() {
		return m_tiles;
	}
	
	/**
	 * Get a tile at certain coordinates
	 * 
	 * @param x the x coordinate of the tile
	 * @param y the y coordinate of the tile
	 * @return the tile at (x,y)
	 */
	public Tile getTile(int x, int y) {	
		return m_tiles[x][y];
	}
	
	/**
	 * Set the tile at certain coordinates to a new tile
	 * 
	 * @param x the x coordinate of the tile
	 * @param y the y coordinate of the tile
	 * @param tile the new tile to be set
	 */
	public void setTile(int x, int y, Tile tile) {
		m_tiles[x][y] = tile;
	}
	
	/**
	 * Set the tile array to be a specified array
	 * 
	 * @param tileArray the new array to be set as tiles
	 */
	public void setTileArray(Tile[][] tileArray) {
		m_tiles = tileArray;
	}
	
	/**
	 * Calls render on each tile on the board.
	 * 
	 * @param g a Graphics object for rendering the board.
	 */
	public void render(Graphics g) {
		// This will be responsible for creating the graphics of the board
		for (int x = 0; x < m_columns; x++) {
			for (int y = 0; y < m_rows; y++) {
				m_tiles[x][y].render(g, x, y);
			}
		}
	}
	
	private int m_rows;
	private int m_columns;
	private Tile[][] m_tiles;
}
