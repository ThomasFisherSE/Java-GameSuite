/**
 * @file GameAi.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see KablewieAi.java, LudoAi.java
 * @brief Ai interface for playing games
 *
 * An ai interface providing the foundation of a game ai without implementation
 */

package gamesuite;

public interface GameAi extends Runnable {	

	/**
	 * Generate a list of moves that can be made by the ai
	 * 
	 * @return true if generated succesfully, false otherwise
	 */
	public abstract boolean generateMoves();
	
	/**
	 * Make a move in a game
	 * 
	 * @return true if successful move, false otherwise
	 */
	public abstract boolean makeMove();
	
	/**
	 * Set the interval between moves
	 * 
	 * @return true if set successfully, false otherwise
	 */
	public abstract boolean setTime(double time);
}
