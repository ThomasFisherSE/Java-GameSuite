/**
 * @file Tile.java
 * @author Thomas Fisher-A6
 * @date 23 April 2016
 * @see Board.java, LudoTile.java, KablewieTile.java
 * @brief A generic tile to be used in a game board
 *
 * A generic tile that could be used in the game board of many 2D games
 */

package gamesuite;

import java.awt.Graphics;

public abstract class Tile {
	/**
	 * Constructor for a tile given dimensions
	 * 
	 * @param width the width of the tile in pixels
	 * @param height the height of the tile in pixels
	 */
	public Tile(int width, int height) {
		m_width = width;
		m_height = height;
	}
	
	/**
	 * Constructor for a tile given no arguments
	 */
	public Tile() {
		this(DEFAULT_TILE_WIDTH, DEFAULT_TILE_HEIGHT);
	}
	
	/**
	 * Get the height of the tile
	 * 
	 * @return the height in pixels of the tile
	 */
	public int getHeight() {
		return m_height;
	}
	
	/**
	 * Get the width of the tile
	 * 
	 * @return the width in pixels of the tile
	 */
	public int getWidth() {
		return m_width;
	}
	
	/**
	 * Render the tile
	 *  
	 * @param g a Graphics object used to render
	 * @param xLocation the X coordinate to render at
	 * @param yLocation the Y coordinate to render at
	 */
	public abstract void render(Graphics g, int xLocation, int yLocation);
	
	private int m_width;
	private int m_height;
	
	public final static int DEFAULT_TILE_WIDTH = 30;
	public final static int DEFAULT_TILE_HEIGHT = 30;
}
